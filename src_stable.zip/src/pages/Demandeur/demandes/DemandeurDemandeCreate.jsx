/* eslint-disable react/prop-types */
/* eslint-disable react/no-unescaped-entities */
/* eslint-disable no-unused-vars */
"use client";
import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import {
  Button,
  Card,
  Form,
  Input,
  Select,
  Space,
  DatePicker,
  Checkbox,
  Divider,
  Row,
  Col,
  Steps,
  message,
  Popconfirm,
  List,
  Typography,
  Modal,
  Spin,
} from "antd";
import {
  BankOutlined,
  BookOutlined,
  FileTextOutlined,
  TeamOutlined,
  CreditCardOutlined,
  CheckCircleOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";
import demandeService from "@/services/demandeService";
import organizationService from "@/services/organizationservice";
import filiereService from "@/services/filiereService";
import { useAuth } from "@/hooks/useAuth";
import OrgNotifyPicker from "@/components/OrgNotifyPicker";
import { Elements } from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import CheckoutForm from "../../../components/payment/CheckoutForm";
import paymentService, { getPayPalConfig } from "../../../services/paymentService";
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
import { useNavigate } from "react-router-dom";
import countries from "@/assets/countries.json";

const { Text } = Typography;

/** ====== Payment Config (devient fallback seulement) ====== */
const DEFAULT_CURRENCY = "USD";
const DRAFT_KEY = "demande:draft:v4";

const isDay = (d) => dayjs.isDayjs(d);
const reviveDate = (v) => {
  if (!v) return null;
  if (isDay(v)) return v;
  const d = dayjs(v);
  return d.isValid() ? d : null;
};
const serializeFormValues = (values) => {
  const out = { ...values };
  ["dob", "graduationDate"].forEach((k) => {
    const v = values?.[k];
    if (!v) {
      out[k] = null;
      return;
    }
    if (isDay(v)) out[k] = v.toDate().toISOString();
    else if (v instanceof Date) out[k] = v.toISOString();
    else {
      const d = dayjs(v);
      out[k] = d.isValid() ? d.toDate().toISOString() : null;
    }
  });
  return out;
};
const toISO = (d) => {
  if (!d) return null;
  if (isDay(d)) return d.toDate().toISOString();
  if (d instanceof Date) return d.toISOString();
  const parsed = dayjs(d);
  return parsed.isValid() ? parsed.toDate().toISOString() : null;
};
const nullIfEmpty = (v) => (v === "" || v === undefined ? null : v);
const isEmail = (s) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(s || "").trim());

export default function DemandeurDemandeCreate() {
  /** State */
  const { user: me } = useAuth();
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [current, setCurrent] = useState(0);
  const [loading, setLoading] = useState(false);
  const [lastPaymentMeta, setLastPaymentMeta] = useState(null);
  // Paiement
  const [paymentMethod, setPaymentMethod] = useState(null); // "stripe" | "paypal"
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentCompleted, setPaymentCompleted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Stripe
  const [stripePromise, setStripePromise] = useState(null);
  const [clientSecret, setClientSecret] = useState(""); // pi_..._secret_...
  const [initializingStripe, setInitializingStripe] = useState(false);

  // Orgs/filieres
  const [orgs, setOrgs] = useState([]);
  const [tradOrgs, setTradOrgs] = useState([]);
  const [filieres, setFilieres] = useState([]);
  const [filieresLoading, setFilieresLoading] = useState(false);

  // Invitations / notifications
  const [invites, setInvites] = useState([]);
  const [invite, setInvite] = useState({ name: "", email: "", phone: "", address: "", roleKey: "" });
  const [selectedNotifyOrgIds, setSelectedNotifyOrgIds] = useState([]);

  // Draft
  const [savingDraft, setSavingDraft] = useState(false);

  // Prix dynamique
  const [price, setPrice] = useState({ amount: 49, currency: DEFAULT_CURRENCY }); // fallback
  const priceLabel = useMemo(
    () => `${Number(price.amount || 0).toFixed(2)} ${String(price.currency || DEFAULT_CURRENCY).toUpperCase()}`,
    [price],
  );

  /** ------- DRAFT ------- */
  const saveDraft = useCallback(() => {
    try {
      const rawValues = form.getFieldsValue(true);
      const values = serializeFormValues(rawValues);
      const draft = {
        values,
        current,
        invites,
        selectedNotifyOrgIds,
        paymentMethod,
        paymentCompleted,
      };
      localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
      setSavingDraft(false);
    } catch (e) {
      console.error("Échec sauvegarde brouillon:", e);
      message.error("Impossible d'enregistrer le brouillon");
    }
  }, [form, current, invites, selectedNotifyOrgIds, paymentMethod, paymentCompleted]);

  const loadDraft = useCallback(() => {
    try {
      const draft = localStorage.getItem(DRAFT_KEY);
      if (!draft) return;
      const parsed = JSON.parse(draft);
      const values = { ...(parsed.values || {}) };
      values.dob = reviveDate(values.dob);
      values.graduationDate = reviveDate(values.graduationDate);
      form.setFieldsValue(values);
      setCurrent(parsed.current ?? 0);
      setInvites(parsed.invites ?? []);
      setSelectedNotifyOrgIds(parsed.selectedNotifyOrgIds ?? []);
      setPaymentMethod(parsed.paymentMethod ?? null);
      setPaymentCompleted(parsed.paymentCompleted ?? false);
      message.success("Brouillon chargé");
    } catch (e) {
      console.error("Échec chargement brouillon:", e);
    }
  }, [form]);

  const resetDraft = () => {
    try {
      localStorage.removeItem(DRAFT_KEY);
      message.success("Brouillon réinitialisé");
    } catch (e) {
      console.error("Échec réinitialisation brouillon:", e);
      message.error("Impossible de réinitialiser le brouillon");
    }
  };

  /** Auto-save draft */
  useEffect(() => {
    const timer = setTimeout(() => {
      if (!isSubmitting) saveDraft();
    }, 1000);
    return () => clearTimeout(timer);
  }, [form, current, invites, selectedNotifyOrgIds, paymentMethod, paymentCompleted, saveDraft, isSubmitting]);

  /** Load draft on mount */
  useEffect(() => {
    loadDraft();
  }, [loadDraft]);

  /** Load organizations */
  useEffect(() => {
    (async () => {
      try {
        const res = await organizationService.list({ limit: 500 });
        const all = res?.organizations ?? res?.data?.organizations ?? [];
        setOrgs(all.filter((o) => o.type !== "TRADUCTEUR"));
        setTradOrgs(all.filter((o) => o.type === "TRADUCTEUR"));
      } catch {
        message.error("Échec de chargement des organisations");
      }
    })();
  }, []);


  /** Prix dynamique */
  useEffect(() => {
    (async () => {
      try {
        const res = await paymentService.getPriceDemandeDemandeur();
        console.log("PRICE:", res);
        const amt = Number(res?.amount);
        const cur = String(res?.currency || DEFAULT_CURRENCY).toUpperCase();
        if (!amt || amt <= 0) {
          message.error("Montant d’abonnement invalide côté serveur.");
        } else {
          setPrice({ amount: amt, currency: cur });
        }
      } catch (e) {
        console.error(e);
        // message.error("Impossible de récupérer le prix de l’abonnement. Utilisation du fallback local.");
      }
    })();
  }, []);


  /** Load filieres by target org */
  const targetOrgId = Form.useWatch("targetOrgId", form);
  useEffect(() => {
    const loadFilieres = async () => {
      if (!targetOrgId) {
        setFilieres([]);
        return;
      }
      setFilieresLoading(true);
      try {
        const res = await filiereService.listByOrganization({
          page: 1,
          limit: 500,
          organizationId: targetOrgId,
        });
        const list = res?.filieres || res?.data?.filieres || [];
        setFilieres(list);
      } catch {
        setFilieres([]);
        message.error("Impossible de charger les filières de cette organisation");
      } finally {
        setFilieresLoading(false);
      }
    };
    loadFilieres();
    form.setFieldsValue({ intendedMajor: undefined });
  }, [targetOrgId, form]);

  /** ------- STRIPE INIT ------- */
  useEffect(() => {
    (async () => {
      try {
        const response = await paymentService.getPublishableKey(); // { publishable_key }
        const publishableKey = response?.publishable_key;
        if (!publishableKey) throw new Error("Clé publique Stripe manquante");
        const stripe = await loadStripe(publishableKey);
        setStripePromise(stripe);
      } catch (error) {
        console.error("Erreur configuration Stripe:", error);
        message.error("Impossible d'initialiser Stripe");
      }
    })();
  }, []);

  /** ------- CHOIX PAIEMENT ------- */
  const handlePaymentSelection = async (method) => {
    setPaymentMethod(method);
    setShowPaymentModal(true);

    if (method === "stripe") {
      // Créer/renouveler un PaymentIntent à la demande
      try {
        setInitializingStripe(true);
        const amountCents = Math.round(Number(price.amount || 0) * 100);
        if (!me?.id || amountCents <= 0) throw new Error("Paramètres Stripe invalides");
        const resp = await paymentService.createPaymentIntentDemandeur({
          demandeurId: me.id,
          amount: amountCents, // en cents
          currency: String(price.currency || DEFAULT_CURRENCY),
        });
        const cs = resp?.clientSecret || resp?.client_secret;
        if (!cs?.includes("_secret_")) throw new Error("Client secret Stripe invalide/absent");
        setClientSecret(cs);
      } catch (e) {
        console.error(e);
        message.error(e?.message || "Impossible de créer le PaymentIntent");
      } finally {
        setInitializingStripe(false);
      }
    }
  };

  // const handlePayment = async (method, paymentData) => {
  //   try {
  //     if (method === "stripe") {
  //       if (paymentData?.status === "succeeded") {
  //         setPaymentCompleted(true);
  //         setShowPaymentModal(false);
  //         message.success("Paiement Stripe confirmé !");
  //         return;
  //       }
  //       // (optionnel) conf server si tu as un endpoint /stripe/confirm
  //       message.success("Stripe: paiement confirmé côté client.");
  //       setPaymentCompleted(true);
  //       setShowPaymentModal(false);
  //     } else if (method === "paypal") {
  //       // paymentData vient de onApprove (order)
  //       if (paymentData?.status === "COMPLETED" || paymentData?.status === "PAID") {
  //         setPaymentCompleted(true);
  //         setShowPaymentModal(false);
  //         message.success("Paiement PayPal confirmé !");
  //         return;
  //       }
  //       message.warning(`Statut PayPal: ${paymentData?.status || "inconnu"}`);
  //     }
  //   } catch (error) {
  //     console.error("Erreur paiement:", error);
  //     message.error(`Échec du paiement: ${error.message}`);
  //   }
  // };

  const handlePayment = async (method, paymentData) => {
    try {
      if (method === "stripe") {
        // paymentData ~ PaymentIntent ou objet renvoyé par CheckoutForm
        const status = paymentData?.status || "succeeded";
        const providerRef = paymentData?.id || paymentData?.payment_intent || "unknown";
        setLastPaymentMeta({
          provider: "stripe",
          providerRef,
          status,
          amount: Number(price.amount),
          currency: String(price.currency || DEFAULT_CURRENCY),
          paymentType: "card",
          paymentInfo: paymentData || null,
        });
        setPaymentCompleted(true);
        setShowPaymentModal(false);
        message.success("Paiement Stripe confirmé !");
        return;
      }

      if (method === "paypal") {
        // `paymentData` = résultat de `actions.order.capture()`
        const status = paymentData?.status || "COMPLETED";
        const providerRef = paymentData?.id || "unknown";
        // récupération du montant si dispo
        const capturedAmt =
          paymentData?.purchase_units?.[0]?.payments?.captures?.[0]?.amount?.value ??
          paymentData?.purchase_units?.[0]?.amount?.value ??
          price.amount;

        const capturedCur =
          paymentData?.purchase_units?.[0]?.payments?.captures?.[0]?.amount?.currency_code ??
          paymentData?.purchase_units?.[0]?.amount?.currency_code ??
          price.currency;

        setLastPaymentMeta({
          provider: "paypal",
          providerRef,
          status,
          amount: Number(capturedAmt || price.amount),
          currency: String(capturedCur || price.currency || DEFAULT_CURRENCY),
          paymentType: "paypal",
          paymentInfo: paymentData || null,
        });
        setPaymentCompleted(true);
        setShowPaymentModal(false);
        message.success("Paiement PayPal confirmé !");
        return;
      }
    } catch (error) {
      console.error("Erreur paiement:", error);
      message.error(`Échec du paiement: ${error.message}`);
    }
  };

  /** ------- Étapes ------- */
  const PERIODES = useMemo(
    () => [
      { value: "FALL", label: "Automne / Fall" },
      { value: "WINTER", label: "Hiver / Winter" },
      { value: "SPRING", label: "Printemps / Spring" },
      { value: "SUMMER", label: "Été / Summer" },
    ],
    []
  );

  const YEAR_OPTIONS = useMemo(() => {
    const start = dayjs().year();
    return Array.from({ length: 11 }, (_, i) => {
      const y = String(start + i);
      return { value: y, label: y };
    });
  }, []);

  const YEAR_OPTIONS_PAST = useMemo(() => {
    const currentYear = dayjs().year();
    return Array.from({ length: 31 }, (_, i) => {
      const y = String(currentYear - i);
      return { value: y, label: y };
    });
  }, []);

  const steps = [
    { title: "Cible & identité", icon: <BankOutlined /> },
    { title: "Académique", icon: <BookOutlined /> },
    { title: "Essays & Divers", icon: <FileTextOutlined /> },
    { title: "Invitations + Récap", icon: <TeamOutlined /> },
    { title: "Paiement", icon: <CreditCardOutlined /> },
  ];

  const next = async () => {
    if (current === 0) await form.validateFields(["targetOrgId"]);
    setCurrent((c) => c + 1);
  };
  const prev = () => setCurrent((c) => c - 1);

  /** ------- Submit ------- */
  const onFinish = async (values) => {
    if (!paymentCompleted) {
      message.warning("Veuillez compléter le paiement avant de soumettre");
      return;
    }
    try {
      setLoading(true);
      setIsSubmitting(true);

      const englishProficiencyTests = Array.isArray(values.englishProficiencyTests)
        ? values.englishProficiencyTests
        : values.englishProficiencyTests || null;
      const examsTaken = Array.isArray(values.examsTaken) ? values.examsTaken : values.examsTaken || null;

      let intendedMajorText = values.intendedMajor;
      if (typeof intendedMajorText === "object" && intendedMajorText?.label) intendedMajorText = intendedMajorText.label;

      const payload = {
        targetOrgId: values.targetOrgId,
        assignedOrgId: values.assignedOrgId || null,
        userId: me?.id,
        notifyOrgIds: selectedNotifyOrgIds,

        // Programme
        periode: nullIfEmpty(values.periode),
        year: nullIfEmpty(values.year),

        // Identité & académique
        observation: nullIfEmpty(values.observation),
        serie: nullIfEmpty(values.serie),
        niveau: nullIfEmpty(values.niveau),
        mention: nullIfEmpty(values.mention),
        annee: nullIfEmpty(values.annee),
        countryOfSchool: nullIfEmpty(values.countryOfSchool),
        secondarySchoolName: nullIfEmpty(values.secondarySchoolName),
        graduationDate: toISO(values.graduationDate),
        dob: toISO(values.dob),
        citizenship: nullIfEmpty(values.citizenship),
        passport: nullIfEmpty(values.passport),

        // Langue & examens
        isEnglishFirstLanguage: !!values.isEnglishFirstLanguage,
        englishProficiencyTests,
        testScores: nullIfEmpty(values.testScores),
        gradingScale: nullIfEmpty(values.gradingScale),
        gpa: nullIfEmpty(values.gpa),
        examsTaken,

        // Filière
        intendedMajor: nullIfEmpty(intendedMajorText),

        // Divers
        extracurricularActivities: nullIfEmpty(values.extracurricularActivities),
        honorsOrAwards: nullIfEmpty(values.honorsOrAwards),
        parentGuardianName: nullIfEmpty(values.parentGuardianName),
        occupation: nullIfEmpty(values.occupation),
        educationLevel: nullIfEmpty(values.educationLevel),
        willApplyForFinancialAid: !!values.willApplyForFinancialAid,
        hasExternalSponsorship: !!values.hasExternalSponsorship,
        visaType: nullIfEmpty(values.visaType),
        hasPreviouslyStudiedInUS: !!values.hasPreviouslyStudiedInUS,
        personalStatement: nullIfEmpty(values.personalStatement),
        optionalEssay: nullIfEmpty(values.optionalEssay),
        applicationRound: nullIfEmpty(values.applicationRound),
        howDidYouHearAboutUs: nullIfEmpty(values.howDidYouHearAboutUs),

        // Invitations
        invitedOrganizations: invites,

        // Paiement
        paymentMethod,
        paymentCompleted,
        pricePaid: Number(price.amount),
        currency: String(price.currency || DEFAULT_CURRENCY),
      };

      const created = await demandeService.create(payload);
      const d = created?.demande || created;
      const data = {
        demandePartageId: d.id,
        provider: lastPaymentMeta.provider,
        providerRef: lastPaymentMeta.providerRef,
        status:
          lastPaymentMeta.provider === "stripe"
            ? (lastPaymentMeta.status || "succeeded").toUpperCase()
            : (lastPaymentMeta.status || "COMPLETED").toUpperCase(),
        amount: Number(lastPaymentMeta.amount || price.amount),
        currency: String(lastPaymentMeta.currency || price.currency || DEFAULT_CURRENCY),
        paymentType: lastPaymentMeta.paymentType,   // "card" | "paypal"
        paymentInfo: lastPaymentMeta.paymentInfo || null,
        // transactionId / abonnementId non fournis ici (optionnels côté backend)
      }
      console.log(data)
      await paymentService.create({
        demandePartageId: d.id,
        provider: lastPaymentMeta.provider,
        providerRef: lastPaymentMeta.providerRef,
        status:
          lastPaymentMeta.provider === "stripe"
            ? (lastPaymentMeta.status || "succeeded").toUpperCase()
            : (lastPaymentMeta.status || "COMPLETED").toUpperCase(),
        amount: Number(lastPaymentMeta.amount || price.amount),
        currency: String(lastPaymentMeta.currency || price.currency || DEFAULT_CURRENCY),
        paymentType: lastPaymentMeta.paymentType,   // "card" | "paypal"
        paymentInfo: lastPaymentMeta.paymentInfo || null,
        // transactionId / abonnementId non fournis ici (optionnels côté backend)
      });

      message.success("Demande créée (invitations & notifications envoyées)");
      try {
        localStorage.removeItem(DRAFT_KEY);
      } catch (e) {
        console.error("Échec suppression brouillon:", e);
      }
      navigate(`/demandeur/mes-demandes/${d.id}/details`);
    } catch (e) {
      console.error(e);
      message.error(e?.response?.data?.message || "Échec de création");
    } finally {
      setLoading(false);
      setIsSubmitting(false);
    }
  };

  /** ------- UI ------- */
  return (
    <PayPalScriptProvider options={getPayPalConfig()}>
      <div className="container-fluid relative px-3" style={{ background: "#f9f9f9", minHeight: "100vh", paddingTop: 20, paddingBottom: 48 }}>
        <div className="layout-specing" style={{ maxWidth: 800, margin: "0 auto" }}>
          <h1 style={{ fontFamily: "Arial, sans-serif", fontSize: 28, fontWeight: "normal", color: "#333", marginBottom: 20 }}>
            International Student Application
          </h1>

          <Card style={{ marginBottom: 20, borderRadius: 0, boxShadow: "0 0 10px rgba(0,0,0,0.05)", background: "white", border: "none" }}>
            <Steps
              current={current}
              items={steps.map((step, idx) => ({
                title: step.title,
                icon: current > idx ? <CheckCircleOutlined /> : step.icon,
                status: current > idx ? "finish" : current === idx ? "process" : "wait",
              }))}
              style={{ padding: "12px 0" }}
            />
          </Card>

          <Card
            title={
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ width: 32, height: 32, borderRadius: "50%", background: "#e0e0e0", display: "flex", alignItems: "center", justifyContent: "center", color: "#333", fontSize: 16 }}>
                  {steps[current].icon}
                </div>
                <div>
                  <div style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333" }}>{steps[current].title}</div>
                  <div style={{ fontFamily: "Arial, sans-serif", fontSize: 13, color: "#666", fontWeight: 400 }}>
                    Step {current + 1} of {steps.length}
                  </div>
                </div>
              </div>
            }
            style={{ borderRadius: 0, boxShadow: "0 0 10px rgba(0,0,0,0.05)", overflow: "hidden", background: "white", border: "none" }}
          >
            <Form form={form} layout="vertical" preserve onFinish={onFinish}>
              {/* STEP 0 */}
              <div style={{ display: current === 0 ? "block" : "none" }}>
                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginBottom: 20 }}>
                  1. Personal Information
                </h2>
                <Row gutter={16}>
                  <Col xs={24} md={12}>
                    <Form.Item
                      label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Target Organization</span>}
                      name="targetOrgId"
                      rules={[{ required: true, message: "Required" }]}
                    >
                      <Select
                        showSearch
                        size="large"
                        placeholder="Choose organization"
                        options={orgs.map((o) => ({ value: o.id, label: `${o.name} — ${o.type}` }))}
                        onChange={() => form.setFieldsValue({ intendedMajor: undefined })}
                        style={{ width: "100%", padding: 8, boxSizing: "border-box" }}
                      />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={12}>
                    <Form.Item
                      label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Translation Organization (optional)</span>}
                      name="assignedOrgId"
                    >
                      <Select
                        allowClear
                        showSearch
                        size="large"
                        placeholder="— optional —"
                        options={tradOrgs.map((o) => ({ value: o.id, label: `${o.name} — TRADUCTEUR` }))}
                        style={{ width: "100%", padding: 8, boxSizing: "border-box" }}
                      />
                    </Form.Item>
                  </Col>
                </Row>

                <Row gutter={16}>
                  <Col xs={24} md={8}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Date of Birth</span>} name="dob" getValueProps={(v) => ({ value: reviveDate(v) })}>
                      <DatePicker className="w-full" size="large" allowClear />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={8}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Country of Citizenship</span>} name="citizenship">
                      <Select
                        allowClear
                        showSearch
                        size="large"
                        placeholder="Select country"
                        options={(countries || []).map((f) => ({ value: f.name, label: f.name }))}
                      />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={8}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Passport Number (optional)</span>} name="passport">
                      <Input size="large" />
                    </Form.Item>
                  </Col>
                </Row>

                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginTop: 30, marginBottom: 20 }}>
                  4. Intended Program of Study
                </h2>
                <Row gutter={16}>
                  <Col xs={24} md={12}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Preferred Start Term</span>} name="periode">
                      <Select allowClear size="large" placeholder="Select term" options={PERIODES} />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={12}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Year</span>} name="year">
                      <Select allowClear size="large" placeholder="Select year" options={YEAR_OPTIONS} />
                    </Form.Item>
                  </Col>
                </Row>
              </div>

              {/* STEP 1 */}
              <div style={{ display: current === 1 ? "block" : "none" }}>
                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginBottom: 20 }}>
                  2. English Language Proficiency
                </h2>
                <Row gutter={16}>
                  <Col xs={24} md={8}>
                    <Form.Item
                      label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Is English your first language?</span>}
                      name="isEnglishFirstLanguage"
                      valuePropName="checked"
                    >
                      <Checkbox style={{ fontFamily: "Arial, sans-serif", fontWeight: 500 }}>Yes</Checkbox>
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={8}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>English Proficiency Test Taken</span>} name="englishProficiencyTests">
                      <Select
                        mode="multiple"
                        size="large"
                        placeholder="Select tests"
                        options={[
                          { value: "TOEFL", label: "TOEFL" },
                          { value: "IELTS", label: "IELTS" },
                          { value: "Duolingo English Test", label: "Duolingo English Test" },
                          { value: "PTE Academic", label: "PTE Academic" },
                          { value: "None", label: "None" },
                        ]}
                        style={{ width: "100%" }}
                      />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={8}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Test Score(s)</span>} name="testScores">
                      <Input.TextArea rows={3} />
                    </Form.Item>
                  </Col>
                </Row>

                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginTop: 30, marginBottom: 20 }}>
                  3. Academic Background
                </h2>
                <Row gutter={16}>
                  <Col xs={24} md={12}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Secondary School Name</span>} name="secondarySchoolName">
                      <Input size="large" />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={12}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Country of School</span>} name="countryOfSchool">
                      <Select
                        allowClear
                        showSearch
                        size="large"
                        placeholder="Select country"
                        options={(countries || []).map((f) => ({ value: f.name, label: f.name }))}
                      />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={8}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Graduation Date</span>} name="graduationDate" getValueProps={(v) => ({ value: reviveDate(v) })}>
                      <DatePicker className="w-full" size="large" allowClear />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={8}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Grading Scale</span>} name="gradingScale">
                      <Input size="large" />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={8}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>GPA or Average</span>} name="gpa">
                      <Input size="large" />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={12}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Exams Taken</span>} name="examsTaken">
                      <Select
                        mode="multiple"
                        size="large"
                        placeholder="Select exams"
                        options={[
                          { value: "A-Levels", label: "A-Levels" },
                          { value: "IB Diploma", label: "IB Diploma" },
                          { value: "WAEC/NECO", label: "WAEC/NECO" },
                          { value: "French Baccalauréat", label: "French Baccalauréat" },
                          { value: "National Exams", label: "National Exams" },
                        ]}
                        style={{ width: "100%" }}
                      />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={12}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Intended Major</span>} name="intendedMajor">
                      <Select
                        allowClear
                        showSearch
                        size="large"
                        placeholder={targetOrgId ? "Select a major" : "Choose organization first"}
                        loading={filieresLoading}
                        disabled={!targetOrgId}
                        options={(filieres || []).map((f) => ({ value: f.name, label: f.name }))}
                      />
                    </Form.Item>
                  </Col>
                </Row>
              </div>

              {/* STEP 2 */}
              <div style={{ display: current === 2 ? "block" : "none" }}>
                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginBottom: 20 }}>
                  5. Activities and Achievements
                </h2>
                <Row gutter={16}>
                  <Col xs={24} md={12}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Extracurricular Activities</span>} name="extracurricularActivities">
                      <Input.TextArea rows={4} />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={12}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Honors or Awards</span>} name="honorsOrAwards">
                      <Input.TextArea rows={4} />
                    </Form.Item>
                  </Col>
                </Row>

                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginTop: 30, marginBottom: 20 }}>
                  6. Family Information
                </h2>
                <Row gutter={16}>
                  <Col xs={24} md={8}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Parent/Guardian 1 Name</span>} name="parentGuardianName">
                      <Input size="large" />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={8}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Occupation</span>} name="occupation">
                      <Input size="large" />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={8}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Education Level</span>} name="educationLevel">
                      <Select
                        allowClear
                        size="large"
                        placeholder="Select level"
                        options={[
                          { value: "No formal education", label: "No formal education" },
                          { value: "Secondary", label: "Secondary" },
                          { value: "Bachelor's", label: "Bachelor's" },
                          { value: "Graduate", label: "Graduate" },
                        ]}
                      />
                    </Form.Item>
                  </Col>
                </Row>

                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginTop: 30, marginBottom: 20 }}>
                  7. Financial Information
                </h2>
                <Row gutter={16}>
                  <Col xs={24} md={12}>
                    <Form.Item
                      label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Will you apply for financial aid?</span>}
                      name="willApplyForFinancialAid"
                      valuePropName="checked"
                    >
                      <Checkbox style={{ fontFamily: "Arial, sans-serif", fontWeight: 500 }}>Yes</Checkbox>
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={12}>
                    <Form.Item
                      label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Do you have external sponsorship?</span>}
                      name="hasExternalSponsorship"
                      valuePropName="checked"
                    >
                      <Checkbox style={{ fontFamily: "Arial, sans-serif", fontWeight: 500 }}>Yes</Checkbox>
                    </Form.Item>
                  </Col>
                </Row>

                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginTop: 30, marginBottom: 20 }}>
                  8. Visa Information
                </h2>
                <Row gutter={16}>
                  <Col xs={24} md={12}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Visa Type (if any)</span>} name="visaType">
                      <Select
                        allowClear
                        size="large"
                        placeholder="Select visa type"
                        options={[
                          { value: "None", label: "None" },
                          { value: "F-1 Student Visa", label: "F-1 Student Visa" },
                          { value: "J-1 Exchange", label: "J-1 Exchange" },
                          { value: "Other", label: "Other" },
                        ]}
                      />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={12}>
                    <Form.Item
                      label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Have you previously studied in the U.S.?</span>}
                      name="hasPreviouslyStudiedInUS"
                      valuePropName="checked"
                    >
                      <Checkbox style={{ fontFamily: "Arial, sans-serif", fontWeight: 500 }}>Yes</Checkbox>
                    </Form.Item>
                  </Col>
                </Row>

                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginTop: 30, marginBottom: 20 }}>
                  9. Essays
                </h2>
                <Row gutter={16}>
                  <Col xs={24} md={12}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Personal Statement</span>} name="personalStatement">
                      <Input.TextArea rows={6} />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={12}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Optional Essay / Additional Info</span>} name="optionalEssay">
                      <Input.TextArea rows={6} />
                    </Form.Item>
                  </Col>
                </Row>

                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginTop: 30, marginBottom: 20 }}>
                  10. Submission
                </h2>
                <Row gutter={16}>
                  <Col xs={24} md={12}>
                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>Application Round</span>} name="applicationRound">
                      <Select
                        allowClear
                        size="large"
                        placeholder="Select round"
                        options={[
                          { value: "Regular Decision", label: "Regular Decision" },
                          { value: "Early Action", label: "Early Action" },
                          { value: "Early Decision", label: "Early Decision" },
                        ]}
                      />
                    </Form.Item>
                  </Col>
                  <Col xs={24} md={12}>


                    <Form.Item label={<span style={{ fontFamily: "Arial, sans-serif", fontWeight: "bold" }}>How did you hear about this university?</span>} name="howDidYouHearAboutUs">
                      <Select
                        allowClear
                        size="large"
                        placeholder="Select result"
                        options={[
                          { value: "FACEBOOK", label: "Facebook" },
                          { value: "TWITTER", label: "Twitter" },
                          { value: "INSTAGRAM", label: "Instagram" },
                          { value: "LINKEDIN", label: "LinkedIn" },
                          { value: "AUTRE", label: "Other" },
                        ]}
                      />
                    </Form.Item>

                  </Col>
                </Row>
              </div>

              {/* STEP 3 — Invitations + Summary */}
              <div style={{ display: current === 3 ? "block" : "none" }}>
                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginBottom: 20 }}>
                  Invite Organizations (official invitation)
                </h2>
                <Card style={{ background: "#fafafa", marginBottom: 16, border: "1px solid #e0e0e0" }}>
                  <Row gutter={12} className="mb-2">
                    <Col xs={24} md={6}>
                      <Input placeholder="Name" size="large" value={invite.name} onChange={(e) => setInvite((s) => ({ ...s, name: e.target.value }))} />
                    </Col>
                    <Col xs={24} md={6}>
                      <Input placeholder="Email" size="large" value={invite.email} onChange={(e) => setInvite((s) => ({ ...s, email: e.target.value }))} />
                    </Col>
                    <Col xs={24} md={4}>
                      <Input placeholder="Phone (opt.)" size="large" value={invite.phone} onChange={(e) => setInvite((s) => ({ ...s, phone: e.target.value }))} />
                    </Col>
                    <Col xs={24} md={4}>
                      <Input placeholder="Address (opt.)" size="large" value={invite.address} onChange={(e) => setInvite((s) => ({ ...s, address: e.target.value }))} />
                    </Col>
                    <Col xs={24} md={4}>
                      <Input placeholder="Role (opt.)" size="large" value={invite.roleKey} onChange={(e) => setInvite((s) => ({ ...s, roleKey: e.target.value }))} />
                    </Col>
                  </Row>
                  <Button type="primary" onClick={() => {
                    const n = String(invite.name || "").trim();
                    const e = String(invite.email || "").trim().toLowerCase();
                    const p = String(invite.phone || "").trim();
                    const a = String(invite.address || "").trim();
                    const r = String(invite.roleKey || "").trim();
                    if (n.length < 2) return message.warning("Nom requis (2+ caractères)");
                    if (!isEmail(e)) return message.warning("Email invalide");
                    if (invites.some((x) => x.email === e)) return message.info("Déjà dans la liste");
                    const next = [...invites, { name: n, email: e, phone: p || undefined, address: a || undefined, roleKey: r || undefined }];
                    setInvites(next);
                  }} size="large">
                    Add
                  </Button>
                </Card>

                <List
                  bordered
                  dataSource={invites}
                  locale={{ emptyText: "No organizations invited" }}
                  style={{ marginBottom: 24 }}
                  renderItem={(item) => (
                    <List.Item
                      key={item.email}
                      actions={[
                        <Button key="delete" danger size="small" onClick={() => setInvites((arr) => arr.filter((i) => i.email !== item.email))}>
                          Remove
                        </Button>,
                      ]}
                    >
                      <Space direction="vertical" size={0}>
                        <Text strong>
                          {item.name} {item.roleKey ? `(${item.roleKey})` : ""}
                        </Text>
                        <Text type="secondary">
                          {item.email}
                          {item.phone ? ` • ${item.phone}` : ""}
                        </Text>
                        {item.address ? <Text type="secondary">{item.address}</Text> : null}
                      </Space>
                    </List.Item>
                  )}
                />

                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginTop: 30, marginBottom: 20 }}>
                  Notify Organizations (simple info)
                </h2>
                <OrgNotifyPicker
                  orgs={orgs}
                  targetOrgId={form.getFieldValue("targetOrgId")}
                  value={selectedNotifyOrgIds}
                  onChange={(ids) => setSelectedNotifyOrgIds(ids)}
                />

                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginTop: 30, marginBottom: 20 }}>
                  Summary
                </h2>
                <Summary form={form} invites={invites} />
              </div>

              {/* STEP 4 - Payment */}
              <div style={{ display: current === 4 ? "block" : "none" }}>
                <h2 style={{ fontFamily: "Arial, sans-serif", fontSize: 18, fontWeight: 600, color: "#333", borderBottom: "2px solid #ccc", paddingBottom: 5, marginBottom: 20 }}>
                  Choose your payment method
                </h2>

                <Card style={{ background: "#f5f5f5", color: "#333", marginBottom: 24, border: "1px solid #ccc" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <h3 style={{ fontFamily: "Arial, sans-serif", color: "#333", margin: 0, fontSize: 18 }}>Processing Fee</h3>
                      <p style={{ fontFamily: "Arial, sans-serif", color: "#666", margin: "4px 0 0 0" }}>One-time payment for your application</p>
                    </div>
                    <div style={{ fontFamily: "Arial, sans-serif", fontSize: 32, fontWeight: 700, color: "#333" }}>
                      {priceLabel}
                    </div>
                  </div>
                </Card>

                <Row gutter={16}>
                  <Col xs={24} md={12}>
                    <Card
                      hoverable
                      style={{
                        border: paymentMethod === "stripe" ? "2px solid #1890ff" : "1px solid #d9d9d9",
                        borderRadius: 8,
                        cursor: "pointer",
                        transition: "all 0.3s",
                      }}
                      onClick={() => handlePaymentSelection("stripe")}
                    >
                      <div style={{ textAlign: "center", padding: "24px 0" }}>
                        <CreditCardOutlined style={{ fontSize: 48, color: "#1890ff", marginBottom: 16 }} />
                        <h3 style={{ fontFamily: "Arial, sans-serif", fontSize: 20, fontWeight: 600, marginBottom: 8 }}>Stripe</h3>
                        <p style={{ fontFamily: "Arial, sans-serif", color: "#8c8c8c", marginBottom: 12 }}>Secure credit card</p>
                        <div style={{ display: "inline-block", padding: "4px 12px", background: "#52c41a", color: "white", borderRadius: 12, fontSize: 12, fontWeight: 500 }}>
                          Recommended
                        </div>
                      </div>
                    </Card>
                  </Col>

                  <Col xs={24} md={12}>
                    <Card
                      hoverable
                      style={{
                        border: paymentMethod === "paypal" ? "2px solid #1890ff" : "1px solid #d9d9d9",
                        borderRadius: 8,
                        cursor: "pointer",
                        transition: "all 0.3s",
                      }}
                      onClick={() => handlePaymentSelection("paypal")}
                    >
                      <div style={{ textAlign: "center", padding: "24px 0" }}>
                        <svg style={{ width: 48, height: 48, marginBottom: 16 }} viewBox="0 0 24 24" fill="#0070BA">
                          <path d="M20.067 8.478c.492.88.556 2.014.3 3.327-.74 3.806-3.276 5.12-6.514 5.12h-.5a.805.805 0 0 0-.794.68l-.04.22-.63 3.993-.028.15a.805.805 0 0 1-.794.68H7.72a.483.483 0 0 1-.477-.558L9.22 7.08a.964.964 0 0 1 .952-.814h4.242c.94 0 1.814.078 2.592.28 1.318.34 2.29 1.098 2.817 2.218z" />
                        </svg>
                        <h3 style={{ fontFamily: "Arial, sans-serif", fontSize: 20, fontWeight: 600, marginBottom: 8 }}>PayPal</h3>
                        <p style={{ fontFamily: "Arial, sans-serif", color: "#8c8c8c", marginBottom: 12 }}>PayPal account</p>
                        <div style={{ display: "inline-block", padding: "4px 12px", background: "#f0f0f0", color: "#595959", borderRadius: 12, fontSize: 12, fontWeight: 500 }}>
                          Available
                        </div>
                      </div>
                    </Card>
                  </Col>
                </Row>

                {paymentCompleted && (
                  <Card style={{ marginTop: 24, background: "#f6ffed", border: "1px solid #b7eb8f" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <CheckCircleOutlined style={{ fontSize: 24, color: "#52c41a" }} />
                      <div>
                        <h4 style={{ margin: 0, fontSize: 16, fontWeight: 600, color: "#52c41a" }}>Payment confirmed</h4>
                        <p style={{ margin: "4px 0 0 0", color: "#389e0d" }}>You can now submit your application</p>
                      </div>
                    </div>
                  </Card>
                )}
              </div>

              <Divider className="!mt-6" />
              <div className="flex items-center justify-between">
                <Space>
                  {current > 0 && (
                    <Button onClick={prev} size="large">
                      Previous
                    </Button>
                  )}
                  {current < 4 && (
                    <Button type="primary" onClick={next} size="large">
                      Next
                    </Button>
                  )}
                </Space>
                <Space>
                  <Button onClick={saveDraft} loading={savingDraft} size="large">
                    Save Draft
                  </Button>
                  <Popconfirm
                    title="Reset draft?"
                    description="This will erase locally saved data for this form."
                    onConfirm={resetDraft}
                    okText="Yes"
                    cancelText="No"
                  >
                    <Button danger size="large">
                      Reset
                    </Button>
                  </Popconfirm>
                  {current === 4 && (
                    <Button
                      type="primary"
                      htmlType="submit"
                      loading={loading || isSubmitting}
                      size="large"
                      disabled={!paymentCompleted}
                      style={{
                        background: paymentCompleted ? "#52c41a" : undefined,
                        borderColor: paymentCompleted ? "#52c41a" : undefined,
                      }}
                    >
                      {paymentCompleted ? "Create application & send" : "Complete payment"}
                    </Button>
                  )}
                </Space>
              </div>
            </Form>
          </Card>

          {/* ------ MODAL PAIEMENT (Stripe / PayPal) ------ */}
          <Modal
            title={
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                {paymentMethod === "stripe" ? (
                  <>
                    <CreditCardOutlined style={{ fontSize: 24, color: "#1890ff" }} />
                    <span>Paiement Sécurisé - Stripe</span>
                  </>
                ) : (
                  <>
                    <svg style={{ width: 24, height: 24 }} viewBox="0 0 24 24" fill="#0070BA">
                      <path d="M20.067 8.478c.492.88.556 2.014.3 3.327-.74 3.806-3.276 5.12-6.514 5.12h-.5a.805.805 0 0 0-.794.68l-.04.22-.63 3.993-.028.15a.805.805 0 0 1-.794.68H7.72a.483.483 0 0 1-.477-.558L9.22 7.08a.964.964 0 0 1 .952-.814h4.242c.94 0 1.814.078 2.592.28 1.318.34 2.29 1.098 2.817 2.218z" />
                    </svg>
                    <span>Paiement Sécurisé - PayPal</span>
                  </>
                )}
              </div>
            }
            open={showPaymentModal}
            onCancel={() => setShowPaymentModal(false)}
            footer={null}
            width={600}
            centered
            destroyOnClose
          >
            <div style={{ padding: "24px 0" }}>
              <div
                style={{
                  background: "#f0f5ff",
                  padding: 16,
                  borderRadius: 8,
                  marginBottom: 24,
                  border: "1px solid #adc6ff",
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <h4 style={{ margin: 0, fontSize: 16 }}>Frais de Traitement de Demande</h4>
                    <p style={{ margin: "4px 0 0 0", color: "#8c8c8c", fontSize: 14 }}>
                      Paiement sécurisé par {paymentMethod === "stripe" ? "Stripe" : "PayPal"}
                    </p>
                  </div>
                  <div style={{ fontSize: 24, fontWeight: 700, color: "#1890ff" }}>{priceLabel}</div>
                </div>
              </div>

              {paymentMethod === "stripe" && (
                initializingStripe ? (
                  <div style={{ textAlign: "center", padding: 24 }}>
                    <Spin size="large" tip="Initialisation du paiement…" />
                  </div>
                ) : (stripePromise && clientSecret) ? (
                  <Elements stripe={stripePromise} options={{ clientSecret, appearance: { theme: "stripe" } }}>
                    <CheckoutForm
                      amount={Number(price.amount)}
                      currency={String(price.currency)}
                      clientSecret={clientSecret}
                      onPaymentSuccess={(pi) => handlePayment("stripe", pi)}
                    />
                  </Elements>
                ) : (
                  <div style={{ textAlign: "center" }}>
                    <Button onClick={() => handlePaymentSelection("stripe")}>Réinitialiser Stripe</Button>
                  </div>
                )
              )}

              {paymentMethod === "paypal" && (
                <PayPalButtons
                  style={{ layout: "vertical" }}
                  createOrder={async () => {
                    const resp = await paymentService.createPaypalOrder({
                      demandeurId: me?.id,
                      amount: Number(price.amount),
                      currency: String(price.currency || DEFAULT_CURRENCY),
                    });
                    return resp?.orderID;
                  }}
                  onApprove={async (data, actions) => {
                    const order = await actions.order.capture();
                    await handlePayment("paypal", order);
                  }}
                  onError={(err) => {
                    console.error("PayPal error:", err);
                    message.error("Erreur PayPal: " + (err?.message || "inconnue"));
                  }}
                />
              )}
            </div>
          </Modal>

          {isSubmitting && (
            <div
              style={{
                position: "fixed",
                inset: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: "rgba(0, 0, 0, 0.5)",
                zIndex: 9999,
              }}
            >
              <Card style={{ padding: 24, textAlign: "center" }}>
                <div
                  style={{
                    width: 48,
                    height: 48,
                    border: "4px solid #f3f3f3",
                    borderTop: "4px solid #1890ff",
                    borderRadius: "50%",
                    animation: "spin 1s linear infinite",
                    margin: "0 auto 16px",
                  }}
                />
                <h4 style={{ margin: 0, fontSize: 18, fontWeight: 600 }}>Traitement du paiement...</h4>
                <p style={{ margin: "8px 0 0 0", color: "#8c8c8c" }}>Veuillez patienter</p>
              </Card>
            </div>
          )}
        </div>
      </div>
    </PayPalScriptProvider>
  );
}

/** ---- Récap visuel ---- */
function Summary({ form, invites }) {
  const v = form.getFieldsValue(true);
  const Item = ({ label, value }) => (
    <div className="mb-1">
      <span className="font-medium">{label}:</span> <span>{value ?? "—"}</span>
    </div>
  );
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card size="small" title="Cible" style={{ borderRadius: 8 }}>
        <Item label="Organisation cible" value={v.targetOrgId} />
        <Item label="Org. traduction" value={v.assignedOrgId || "—"} />
        <Item label="Période" value={v.periode || "—"} />
        <Item label="Année" value={v.year || "—"} />
        <Item label="Observation" value={v.observation || "—"} />
      </Card>
      <Card size="small" title="Identité" style={{ borderRadius: 8 }}>
        <Item label="Naissance" value={v.dob ? dayjs(v.dob).format("DD/MM/YYYY") : "—"} />
        <Item label="Nationalité" value={v.citizenship} />
        <Item label="Passeport" value={v.passport} />
      </Card>
      <Card size="small" title="Académique" style={{ borderRadius: 8 }}>
        <Item label="Série / Niveau / Mention" value={[v.serie, v.niveau, v.mention].filter(Boolean).join(" / ") || "—"} />
        <Item label="Année scol." value={v.annee} />
        <Item label="École" value={v.secondarySchoolName} />
        <Item label="Pays" value={v.countryOfSchool} />
        <Item label="Diplôme" value={v.graduationDate ? dayjs(v.graduationDate).format("DD/MM/YYYY") : "—"} />
        <Item label="Filière souhaitée" value={v.intendedMajor} />
      </Card>
      <Card size="small" title="Invitations" style={{ borderRadius: 8 }}>
        {invites?.length ? (
          invites.map((it) => (
            <div key={it.email}>
              • {it.name} {it.roleKey ? `(${it.roleKey})` : ""} — <i>{it.email}</i>
            </div>
          ))
        ) : (
          <div>—</div>
        )}
      </Card>
    </div>
  );
}
