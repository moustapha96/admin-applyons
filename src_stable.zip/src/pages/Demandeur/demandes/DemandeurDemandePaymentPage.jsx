/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
"use client";

import { useEffect, useMemo, useState, useCallback } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import {
  Card,
  Tabs,
  Typography,
  Space,
  Button,
  Alert,
  Breadcrumb,
  Tag,
  Descriptions,
  Divider,
  Skeleton,
  message,
} from "antd";

import { loadStripe } from "@stripe/stripe-js";
import {
  Elements,
  PaymentElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";

import paymentService from "@/services/paymentService";
import demandeService from "@/services/demandeService";

const { Text } = Typography;

/* -------------------------------------------------------
   Helpers UI
------------------------------------------------------- */
const statusColor = (s) =>
  s === "VALIDATED" ? "green" : s === "REJECTED" ? "red" : s === "IN_PROGRESS" ? "gold" : "blue";

/* -------------------------------------------------------
   STRIPE Checkout (PaymentElement)
   - utilise client_secret retourné par /stripe/create-intent
   - confirme le paiement et appelle /stripe/confirm
------------------------------------------------------- */
function StripeCheckout({ demandeId, clientSecret, amount, currency }) {
  const stripe = useStripe();
  const elements = useElements();
  const [submitting, setSubmitting] = useState(false);

  const onPay = async () => {
    if (!stripe || !elements) return;
    setSubmitting(true);
    try {
      // 1) Confirmer côté Stripe (redirections SCA si besoin)
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        // Pas de return_url => on reste en SPA ; Stripe fera modal SCA au besoin
        redirect: "if_required",
      });

      if (error) {
        // Erreurs cartes, SCA cancel, etc.
        throw new Error(error.message || "Paiement refusé");
      }

      // 2) Sécuriser côté serveur (mise à jour DB)
      await paymentService.confirmStripe({
        demandeId,
        paymentIntentId: paymentIntent.id,
      });

      // 3) Succès
      // (le backend met le statut paiement à PAID)
      window.location.reload();
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error(e);
      const msg = e?.response?.data?.message || e?.message || "Échec paiement Stripe";
      // Petit garde-fou sur les doubles erreurs
      if (msg.toLowerCase().includes("invalid api key") || msg.toLowerCase().includes("no such payment_intent")) {
        // clés / config côté serveur
      }
      // Antd
      // eslint-disable-next-line no-undef
      message.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  if (!clientSecret) {
    return (
      <Alert
        type="warning"
        message="Impossible d’initialiser Stripe (client_secret manquant)"
        showIcon
      />
    );
  }

  return (
    <Space direction="vertical" size="middle" className="w-full">
      <Alert
        type="info"
        showIcon
        message={
          <span>
            Montant à régler (carte) : <b>{amount} {currency}</b>
          </span>
        }
        description="Le montant est fixé côté serveur (non modifiable)."
      />
      <div style={{ padding: 12, border: "1px solid #eee", borderRadius: 6 }}>
        <PaymentElement options={{ layout: "tabs" }} />
      </div>
      <Button type="primary" onClick={onPay} loading={submitting} disabled={!stripe || !elements}>
        Payer maintenant
      </Button>
    </Space>
  );
}

/* -------------------------------------------------------
   PAYPAL Buttons
   - appelle /paypal/create-order puis /paypal/capture
------------------------------------------------------- */
function PaypalButtons({ demandeId, amount, currency }) {
  const [sdkReady, setSdkReady] = useState(false);

  // Injecter le SDK paypal côté client
  useEffect(() => {
    const cid = import.meta.env.VITE_PAYPAL_CLIENT_ID;
    if (!cid) return;

    if (document.getElementById("paypal-sdk")) {
      setSdkReady(true);
      return;
    }
    const s = document.createElement("script");
    s.id = "paypal-sdk";
    s.src = `https://www.paypal.com/sdk/js?client-id=${cid}&currency=${currency}`;
    s.onload = () => setSdkReady(true);
    s.onerror = () => message.error("Impossible de charger le SDK PayPal");
    document.body.appendChild(s);
  }, [currency]);

  useEffect(() => {
    if (!sdkReady || !window.paypal) return;

    const containerId = "paypal-buttons-container";
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = "";

    window.paypal
      .Buttons({
        // Le backend recalcule toujours le prix depuis la quote
        createOrder: async () => {
          try {
            const { orderID } = await paymentService.createPaypalOrder({ demandeId });
            return orderID;
          } catch (e) {
            // eslint-disable-next-line no-undef
            message.error(e?.response?.data?.message || "Échec init PayPal");
            throw e;
          }
        },
        onApprove: async (data) => {
          try {
            await paymentService.capturePaypalOrder({ demandeId, orderID: data.orderID });
            // eslint-disable-next-line no-undef
            message.success("Paiement PayPal réussi 🎉");
            window.location.reload();
          } catch (e) {
            // eslint-disable-next-line no-undef
            message.error(e?.response?.data?.message || "Échec capture PayPal");
          }
        },
        onError: (err) => {
          // eslint-disable-next-line no-console
          console.error(err);
          // eslint-disable-next-line no-undef
          message.error("Erreur PayPal");
        },
      })
      .render(`#${containerId}`);
  }, [sdkReady, demandeId, amount, currency]);

  return (
    <Space direction="vertical" size="middle" className="w-full">
      <Alert
        type="info"
        showIcon
        message={
          <span>
            Montant à régler (PayPal) : <b>{amount} {currency}</b>
          </span>
        }
        description="Le montant est fixé côté serveur (non modifiable)."
      />
      <div id="paypal-buttons-container" />
      {!sdkReady && <Alert type="info" message="Chargement du SDK PayPal…" showIcon />}
    </Space>
  );
}

/* -------------------------------------------------------
   PAGE Paiement Demandeur
------------------------------------------------------- */
export default function DemandeurDemandePaymentPage() {
  const { demandeId } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [demande, setDemande] = useState(null);
  const [payInfo, setPayInfo] = useState(null);
  const [quote, setQuote] = useState(null);

  // Stripe publishable key (front)
  const stripePromise = useMemo(() => {
    const key = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY;
    return key ? loadStripe(key) : null;
  }, []);

  // client_secret pour PaymentElement
  const [stripeClientSecret, setStripeClientSecret] = useState("");

  // Prépare tous les éléments de la page (demande + quote + état de paiement + intent Stripe)
  const bootstrap = useCallback(async () => {
    setLoading(true);
    try {
      const [d, p, q] = await Promise.all([
        demandeService.getById(demandeId),
        paymentService.getForDemande(demandeId), // {statusPayment, payment}
        paymentService.getQuote(demandeId),      // {demandeId, amount, currency, reason, pricingSource}
      ]);
      const demandeData = d?.demande || d;
      setDemande(demandeData);
      setPayInfo(p);
      setQuote(q);

      const isPaid =
        (p?.statusPayment || demandeData?.statusPayment)?.toUpperCase?.() === "PAID";
        if (!isPaid && import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY) {
        const { clientSecret } = await paymentService.createStripeIntent({
          demandeId,
        });
        console.log("clientSecret", clientSecret);
        setStripeClientSecret(clientSecret);
      }
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error(e);
      // eslint-disable-next-line no-undef
      message.error(e?.response?.data?.message || "Erreur chargement paiement");
    } finally {
      setLoading(false);
    }
  }, [demandeId]);

  useEffect(() => {
    bootstrap();
  }, [bootstrap]);

  const alreadyPaid =
    (payInfo?.statusPayment || demande?.statusPayment)?.toUpperCase?.() === "PAID";

  const amount = quote?.amount ?? 0;
  const currency = (quote?.currency || "USD").toUpperCase();

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <h5 className="text-lg font-semibold">Paiement de la demande</h5>
          <Breadcrumb
            items={[
              { title: <Link to="/demandeur/dashboard">Dashboard</Link> },
              { title: <Link to="/demandeur/mes-demandes">Mes demandes</Link> },
              { title: <Link to={`/demandeur/mes-demandes/${demandeId}/details`}>Détail</Link> },
              { title: "Paiement" },
            ]}
          />
        </div>

        <Card>
          {loading ? (
            <Skeleton active paragraph={{ rows: 6 }} />
          ) : (
            <>
              {/* Bandeau montant */}
              {quote && (
                <Alert
                  className="mb-4"
                  type="info"
                  showIcon
                  message={
                    <span>
                      Montant total à régler : <b>{amount} {currency}</b>
                    </span>
                  }
                  description={
                    <>
                      Tarification appliquée&nbsp;: <b>{quote?.reason}</b>{" "}
                      (source&nbsp;: <code>{quote?.pricingSource}</code>).
                      <br />
                      Le montant est défini côté serveur et ne peut pas être modifié côté client.
                    </>
                  }
                />
              )}

              {/* Infos Demande */}
              <Descriptions
                title="Résumé de la demande"
                bordered
                size="small"
                column={{ xs: 1, sm: 1, md: 2, lg: 3 }}
              >
                <Descriptions.Item label="Code">
                  <Text code>{demande?.code || demandeId}</Text>
                </Descriptions.Item>
                <Descriptions.Item label="Date">
                  {demande?.dateDemande
                    ? new Date(demande.dateDemande).toLocaleString()
                    : "—"}
                </Descriptions.Item>
                <Descriptions.Item label="Statut dossier">
                  <Tag color={statusColor(demande?.status)}>{demande?.status || "PENDING"}</Tag>
                </Descriptions.Item>
                <Descriptions.Item label="Organisation cible">
                  {demande?.targetOrg?.name || "—"}{" "}
                  {demande?.targetOrg?.type ? (
                    <Tag className="ml-1">{demande.targetOrg.type}</Tag>
                  ) : null}
                </Descriptions.Item>
                <Descriptions.Item label="Organisation de traduction">
                  {demande?.assignedOrg?.name || "—"}{" "}
                  {demande?.assignedOrg?.type ? (
                    <Tag className="ml-1">{demande.assignedOrg.type}</Tag>
                  ) : null}
                </Descriptions.Item>
                <Descriptions.Item label="Statut paiement">
                  <Tag color={alreadyPaid ? "green" : "volcano"}>
                    {alreadyPaid ? "PAID" : (demande?.statusPayment || "UNPAID")}
                  </Tag>
                </Descriptions.Item>
              </Descriptions>

              <Divider />

              {/* Si déjà payé, on bloque tout */}
              {alreadyPaid ? (
                <Alert
                  type="success"
                  showIcon
                  message="Cette demande est déjà payée ✅"
                  description={
                    <Space direction="vertical">
                      <div>
                        <Text strong>Demande :</Text> <Text code>{demande?.code}</Text>
                      </div>
                      <Button onClick={() => navigate(`/demandeur/mes-demandes/${demandeId}/details`)}>
                        Retour au détail
                      </Button>
                    </Space>
                  }
                />
              ) : (
                <>
                  <Space direction="vertical" size="large" className="w-full">
                    <Tabs
                      items={[
                        {
                          key: "stripe",
                          label: "Carte (Stripe)",
                          children: stripePromise ? (
                            stripeClientSecret ? (
                              <Elements
                                stripe={stripePromise}
                                options={{
                                  clientSecret: stripeClientSecret,
                                  appearance: { theme: "stripe" },
                                }}
                              >
                                <StripeCheckout
                                  demandeId={demandeId}
                                  clientSecret={stripeClientSecret}
                                  amount={amount}
                                  currency={currency}
                                />
                              </Elements>
                            ) : (
                              <Alert
                                type="warning"
                                message="Stripe initialisé, mais client_secret absent"
                              />
                            )
                          ) : (
                            <Alert
                              type="warning"
                              message="Stripe non configuré (VITE_STRIPE_PUBLISHABLE_KEY manquant)"
                            />
                          ),
                        },
                        {
                          key: "paypal",
                          label: "PayPal",
                          children: import.meta.env.VITE_PAYPAL_CLIENT_ID ? (
                            <PaypalButtons
                              demandeId={demandeId}
                              amount={amount}
                              currency={currency}
                            />
                          ) : (
                            <Alert
                              type="warning"
                              message="PayPal non configuré (VITE_PAYPAL_CLIENT_ID manquant)"
                            />
                          ),
                        },
                      ]}
                    />
                    <div className="flex gap-2">
                      <Button onClick={() => navigate(`/demandeur/mes-demandes/${demandeId}/details`)}>
                        Retour au détail
                      </Button>
                    </div>
                  </Space>
                </>
              )}
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
