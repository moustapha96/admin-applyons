/* eslint-disable react/no-unescaped-entities */

import { useEffect,  useState } from "react";
import { Link,  useParams } from "react-router-dom";
import {
  Breadcrumb,
  Card,
  Descriptions,
  Avatar,
  Tag,
  Space,
  Spin,
  message,
} from "antd";
import {
  GlobalOutlined,
  PhoneOutlined,
  MailOutlined,
  EnvironmentOutlined,

} from "@ant-design/icons";
import organizationService from "../../../services/organizationservice";
import { BiBuilding } from "react-icons/bi";


const typeOptions = [
  { value: "ENTREPRISE", label: "Entreprise" },
  { value: "TRADUCTEUR", label: "Agence de Traduction" },
  { value: "BANQUE", label: "Banque" },
  { value: "COLLEGE", label: "Collège" },
  { value: "LYCEE", label: "Lycée" },
  { value: "UNIVERSITE", label: "Université" },
];

const countryOptions = [
  { value: "SN", label: "Sénégal" },
  { value: "FR", label: "France" },
  { value: "US", label: "États-Unis" },
  { value: "CA", label: "Canada" },
];

const getTypeColor = (type) => {
  const colors = {
    ENTREPRISE: "blue",
    TRADUCTEUR: "purple",
    BANQUE: "gold",
    COLLEGE: "green",
    LYCEE: "cyan",
    UNIVERSITE: "geekblue",
  };
  return colors[type] || "default";
};


const defaultUsersState = {
  page: 1,
  limit: 10,
  search: "",
  role: undefined,
  sortBy: "createdAt",
  sortOrder: "desc",
};

const DemandeurOrganisationDetail = () => {
  const { id } = useParams();

  const [organization, setOrganization] = useState(null);
  const [loadingOrg, setLoadingOrg] = useState(true);

  const [usersState, setUsersState] = useState(defaultUsersState);
  const [loadingUsers, setLoadingUsers] = useState(true);

  const fetchOrganization = async (overrideUsersState) => {
    const s = { ...usersState, ...(overrideUsersState || {}) };
    setLoadingOrg(true);
    setLoadingUsers(true);
    try {
      const response = await organizationService.getById(id, {
        usersPage: s.page,
        usersLimit: s.limit,
        usersSearch: s.search || undefined,
        usersRole: s.role || undefined,
        usersSortBy: s.sortBy,
        usersSortOrder: s.sortOrder,
      });

      setOrganization(response.organization || null);
    } catch (error) {
        console.log(error)
    message.warning(error.message)
        console.error("Erreur lors de la récupération de l'organisation:", error);
      setOrganization(null);
    } finally {
      setLoadingOrg(false);
      setLoadingUsers(false);
    }
  };

  useEffect(() => {
    document.documentElement.setAttribute("dir", "ltr");
    document.documentElement.classList.add("light");
    document.documentElement.classList.remove("dark");
    fetchOrganization();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);


  if (loadingOrg && !organization) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Spin size="large" />
      </div>
    );
  }

  if (!organization) {
    return <div>Organisation non trouvée.</div>;
  }

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <h5 className="text-lg font-semibold">Détails de l'organisation</h5>
          <Breadcrumb
            items={[
              { title: <Link to="/demandeur/dashboard">Dashboard</Link> },
              { title: organization.name },
            ]}
          />
        </div>

       
        <Card>
          <Descriptions title="Informations générales" bordered>
            <Descriptions.Item label="Nom" span={2}>
              <Space>
                <Avatar shape="square" size="large" icon={<BiBuilding />} />
                <span className="ml-3">{organization.name}</span>
              </Space>
            </Descriptions.Item>
            <Descriptions.Item label="Type">
              <Tag color={getTypeColor(organization.type)}>
                {typeOptions.find((opt) => opt.value === organization.type)?.label || organization.type}
              </Tag>
            </Descriptions.Item>

        
            <Descriptions.Item label="Email">
              <Space>
                <MailOutlined />
                <a href={`mailto:${organization.email}`}>{organization.email}</a>
              </Space>
            </Descriptions.Item>

            <Descriptions.Item label="Téléphone">
              <Space>
                <PhoneOutlined />
                <a href={`tel:${organization.phone}`}>{organization.phone}</a>
              </Space>
            </Descriptions.Item>

            <Descriptions.Item label="Adresse">
              <Space>
                <EnvironmentOutlined />
                <span>{organization.address || "—"}</span>
              </Space>
            </Descriptions.Item>

            <Descriptions.Item label="Site Web">
              <Space>
                <GlobalOutlined />
                {organization.website ? (
                  <a href={organization.website} target="_blank" rel="noopener noreferrer">
                    {organization.website}
                  </a>
                ) : (
                  "N/A"
                )}
              </Space>
            </Descriptions.Item>

            <Descriptions.Item label="Pays">
              <Tag color="blue">
                {countryOptions.find((opt) => opt.value === organization.country)?.label || organization.country}
              </Tag>
            </Descriptions.Item>

            
          </Descriptions>

         
         
        </Card>

        
        
      </div>
    </div>
  );
};

export default DemandeurOrganisationDetail;
