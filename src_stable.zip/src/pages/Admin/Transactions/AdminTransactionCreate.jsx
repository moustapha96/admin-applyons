"use client";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Breadcrumb, Button, Card, Form, Input, InputNumber, Select, DatePicker, message, Row, Col, Space } from "antd";
import dayjs from "dayjs";
import transactionService from "../../../services/transactionService";


export default function AdminTransactionCreate() {
  const [form] = Form.useForm();
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();

  const onFinish = async (vals) => {
    try {
      setSaving(true);
      const payload = {
        demandePartageId: vals.demandePartageId,
        userId: vals.userId || undefined,
        montant: vals.montant,
        typePaiement: vals.typePaiement,
        typeTransaction: vals.typeTransaction || undefined,
        statut: vals.statut || "PENDING",
        dateTransaction: vals.dateTransaction ? vals.dateTransaction.toISOString() : undefined, // si tu gères côté back
      };
      const res = await transactionService.create(payload);
      const created = res?.transaction || res;
      message.success("Transaction créée");
      navigate(`/admin/transactions/${created.id}/details`);
    } catch (e) {
      message.error(e?.response?.data?.message || "Échec de création");
    } finally { setSaving(false); }
  };

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <h5 className="text-lg font-semibold">Nouvelle transaction</h5>
          <Breadcrumb items={[
            { title: <Link to="/admin/dashboard">Dashboard</Link> },
            { title: <Link to="/admin/transactions">Transactions</Link> },
            { title: "Créer" },
          ]}/>
        </div>

        <Card>
          <Form form={form} layout="vertical" onFinish={onFinish} initialValues={{ statut: "PENDING" }}>
            <Row gutter={16}>
              <Col xs={24} md={12}>
                <Form.Item label="DemandePartage ID" name="demandePartageId" rules={[{ required: true, message: "Requis" }]}>
                  <Input placeholder="ID de la demande (demandePartageId)" />
                </Form.Item>
              </Col>
              <Col xs={24} md={12}>
                <Form.Item label="Utilisateur (optionnel)" name="userId">
                  <Input placeholder="userId (optionnel)" />
                </Form.Item>
              </Col>
            </Row>

            <Row gutter={16}>
              <Col xs={24} md={8}>
                <Form.Item label="Montant (XOF)" name="montant" rules={[{ required: true, message: "Requis" }]}>
                  <InputNumber min={0} className="w-full" />
                </Form.Item>
              </Col>
              <Col xs={24} md={8}>
                <Form.Item label="Type paiement" name="typePaiement" rules={[{ required: true, message: "Requis" }]}>
                  <Select
                    options={[
                      { value: "STRIPE", label: "STRIPE" },
                      { value: "PAYPAL", label: "PAYPAL" },
                      { value: "CASH", label: "CASH" },
                      { value: "WIRE", label: "VIREMENT" },
                    ]}
                  />
                </Form.Item>
              </Col>
              <Col xs={24} md={8}>
                <Form.Item label="Type transaction" name="typeTransaction">
                  <Input placeholder="EX: ACOMPTE / SOLDE / FRAIS_DOSSIER…" />
                </Form.Item>
              </Col>
            </Row>

            <Row gutter={16}>
              <Col xs={24} md={8}>
                <Form.Item label="Statut" name="statut">
                  <Select
                    options={[
                      { value: "PENDING", label: "PENDING" },
                      { value: "COMPLETED", label: "COMPLETED" },
                      { value: "FAILED", label: "FAILED" },
                    ]}
                  />
                </Form.Item>
              </Col>
              <Col xs={24} md={8}>
                <Form.Item label="Date (optionnel)" name="dateTransaction">
                  <DatePicker className="w-full" disabledDate={(d)=> d && d > dayjs()} />
                </Form.Item>
              </Col>
            </Row>

            <Space>
              <Button onClick={()=> navigate(-1)}>Annuler</Button>
              <Button type="primary" htmlType="submit" loading={saving}>Créer</Button>
            </Space>
          </Form>
        </Card>
      </div>
    </div>
  );
}
