// src/pages/Admin/Demandes/AdminDemandesList.jsx
"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Table,
  Tag,
  Space,
  Breadcrumb,
  Button,
  Input,
  Select,
  message,
  DatePicker,
  Badge,
  Card,
} from "antd";
import { SearchOutlined, FileTextOutlined, ReloadOutlined } from "@ant-design/icons";
import dayjs from "dayjs";

import demandeService from "@/services/demandeService";
import organizationService from "@/services/organizationService";

const { RangePicker } = DatePicker;

const statusOptions = [
  { value: "PENDING",     label: "En attente" },
  { value: "IN_PROGRESS", label: "En cours" },
  { value: "VALIDATED",   label: "Validée" },
  { value: "REJECTED",    label: "Rejetée" },
];

const getStatusColor = (status) => {
  switch (status) {
    case "VALIDATED":   return "green";
    case "REJECTED":    return "red";
    case "IN_PROGRESS": return "gold";
    default:            return "blue";
  }
};

// Couleurs pour paiement
const getPayColor = (s) => {
  switch (s) {
    case "PAID":         return "green";
    case "PENDING":      return "gold";
    case "REQUIRES_ACTION":
    case "REQUIRES_CAPTURE":
    case "requires_action":
    case "processing":   return "blue";
    case "FAILED":
    case "CANCELED":
    case "canceled":
    case "failed":       return "red";
    default:             return "default";
  }
};

// Récupère un statut paiement robuste selon ce que renvoie la liste
// (r.statusPayment || r.payment?.status || r.transaction?.statut || r.transaction?.status)
const extractPayStatus = (r) =>
  r?.statusPayment ||
  r?.payment?.status ||
  r?.transaction?.statut ||
  r?.transaction?.status ||
  null;

const extractPayAmount = (r) => {
  const amt = r?.payment?.amount ?? r?.transaction?.montant ?? r?.transaction?.amount;
  const cur = r?.payment?.currency ?? r?.transaction?.devise ?? r?.transaction?.currency;
  if (amt == null) return null;
  return { amt, cur: cur || "" };
};

export default function AdminDemandesList() {
  const navigate = useNavigate();

  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [pagination, setPagination] = useState({ current: 1, pageSize: 10, total: 0 });
  const [sort, setSort] = useState({ field: "createdAt", order: "descend" });

  const [orgs, setOrgs] = useState([]);
  const [filters, setFilters] = useState({
    search: "",
    status: undefined,
    targetOrgId: undefined,
    assignedOrgId: undefined,
    from: undefined,
    to: undefined,
  });

  // Charger organisations pour filtres
  useEffect(() => {
    (async () => {
      try {
        const res = await organizationService.list({ page: 1, limit: 500 });
        setOrgs(res?.organizations || []);
      } catch (e) {
        message.error(e?.response?.data?.message || "Erreur chargement organisations");
      }
    })();
  }, []);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const params = {
        page: pagination.current,
        limit: pagination.pageSize,
        search: filters.search || undefined,
        status: filters.status || undefined,
        targetOrgId: filters.targetOrgId || undefined,
        assignedOrgId: filters.assignedOrgId || undefined,
        from: filters.from || undefined,
        to: filters.to || undefined,
        sortBy: sort.field || "createdAt",
        sortOrder: sort.order === "ascend" ? "asc" : "desc",
      };

      const res = await demandeService.list(params);
      setRows(res?.demandes || []);
      setPagination((p) => ({ ...p, total: res?.pagination?.total || 0 }));
    } catch (e) {
      message.error(e?.response?.data?.message || "Erreur lors du chargement");
    } finally {
      setLoading(false);
    }
  }, [pagination.current, pagination.pageSize, filters, sort]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const orgOptions = useMemo(
    () => orgs.map((o) => ({ value: o.id, label: `${o.name} — ${o.type}` })),
    [orgs]
  );

  const columns = [
    {
      title: "Code",
      dataIndex: "code",
      sorter: true,
      width: 170,
      render: (code, r) => (
        <Space>
          <FileTextOutlined />
          <Link to={`/admin/demandes/${r.id}`}>{code}</Link>
        </Space>
      ),
    },
    {
      title: "Date",
      dataIndex: "dateDemande",
      sorter: true,
      width: 150,
      render: (v) => (v ? dayjs(v).format("DD/MM/YYYY") : "—"),
    },
    {
      title: "Demandeur",
      dataIndex: ["user", "email"],
      render: (_, r) => (
        <div>
          <div>{r.user?.email || "—"}</div>
          <div style={{ fontSize: 12, color: "#888" }}>{r.user?.username || ""}</div>
        </div>
      ),
    },
    {
      title: "Org. cible",
      dataIndex: ["targetOrg", "name"],
      render: (_, r) => (
        <div>
          <div>{r.targetOrg?.name || "—"}</div>
          {r.targetOrg?.type ? <Tag style={{ marginTop: 4 }}>{r.targetOrg.type}</Tag> : null}
        </div>
      ),
    },
    {
      title: "Org. assignée",
      dataIndex: ["assignedOrg", "name"],
      render: (_, r) =>
        r.assignedOrg ? (
          <div>
            <div>{r.assignedOrg.name}</div>
            {r.assignedOrg.slug ? (
              <div style={{ fontSize: 12, color: "#888" }}>{r.assignedOrg.slug}</div>
            ) : null}
          </div>
        ) : (
          <Tag>—</Tag>
        ),
    },
    {
      title: "Docs",
      dataIndex: "documentsCount",
      width: 90,
      render: (v) => <Badge count={v || 0} style={{ backgroundColor: "#1677ff" }} />,
    },
    {
      title: "Statut",
      dataIndex: "status",
      width: 140,
      render: (s) => <Tag color={getStatusColor(s)}>{s || "PENDING"}</Tag>,
    },
    // ======= NOUVELLE COLONNE : PAIEMENT =======
    // ===========================================
    {
      title: "Actions",
      key: "actions",
      fixed: "right",
      width: 210,
      render: (_, r) => (
        <Space wrap>
          <Link to={`/admin/demandes/${r.id}/details`}>
            <Button size="small">Détails</Button>
          </Link>
          <Link to={`/admin/demandes/${r.id}/documents`}>
            <Button size="small">Documents</Button>
          </Link>
        </Space>
      ),
    },
  ];

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <h5 className="text-lg font-semibold">Demandes</h5>
          <Breadcrumb
            items={[
              { title: <Link to="/admin/dashboard">Dashboard</Link> },
              { title: "Demandes" },
            ]}
          />
        </div>

        <Card className="mb-4">
          <Space wrap style={{ width: "100%", justifyContent: "space-between" }}>
            <Space wrap>
              <Input
                allowClear
                placeholder="Recherche (code, email…)"
                style={{ width: 260 }}
                value={filters.search}
                onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
                onPressEnter={fetchData}
                suffix={<SearchOutlined onClick={fetchData} style={{ color: "#aaa" }} />}
              />

              <Select
                allowClear
                placeholder="Statut"
                style={{ width: 180 }}
                value={filters.status}
                options={statusOptions}
                onChange={(v) => setFilters((f) => ({ ...f, status: v || undefined }))}
              />

              <Select
                allowClear
                showSearch
                placeholder="Organisation cible"
                style={{ width: 280 }}
                value={filters.targetOrgId}
                options={orgOptions}
                onChange={(v) => setFilters((f) => ({ ...f, targetOrgId: v || undefined }))}
              />

              <Select
                allowClear
                showSearch
                placeholder="Organisation assignée"
                style={{ width: 280 }}
                value={filters.assignedOrgId}
                options={orgOptions}
                onChange={(v) => setFilters((f) => ({ ...f, assignedOrgId: v || undefined }))}
              />

              <RangePicker
                allowClear
                onChange={(vals) => {
                  const from = vals?.[0] ? vals[0].startOf("day").toISOString() : undefined;
                  const to   = vals?.[1] ? vals[1].endOf("day").toISOString() : undefined;
                  setFilters((f) => ({ ...f, from, to }));
                }}
              />
            </Space>

            <Space>
              <Button icon={<ReloadOutlined />} onClick={fetchData}>Rafraîchir</Button>
            </Space>
          </Space>
        </Card>

        <Table
          rowKey="id"
          loading={loading}
          dataSource={rows}
          columns={columns}
          pagination={{
            ...pagination,
            showSizeChanger: true,
            pageSizeOptions: ["5", "10", "20", "50"],
            showTotal: (t) => `Total ${t} demandes`,
          }}
          onChange={(pg, _f, sorter) => {
            setPagination({ ...pagination, current: pg.current, pageSize: pg.pageSize });
            if (sorter?.field) setSort({ field: sorter.field, order: sorter.order });
          }}
          scroll={{ x: 1280 }}
        />
      </div>
    </div>
  );
}
