/* eslint-disable react/jsx-key */
// src/pages/Admin/Demandes/AdminDemandeDetail.jsx
"use client";
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  Breadcrumb,
  Card,
  Descriptions,
  Space,
  Button,
  Divider,
  Tag,
  Spin,
  Tabs,
  Modal,
  message,
  
} from "antd";
import {
  FileTextOutlined,
  ArrowLeftOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";

import demandeService from "@/services/demandeService";
import documentService from "@/services/documentService";

const { TabPane } = Tabs;

const statusTagColor = (s) => {
  switch (s) {
    case "VALIDATED": return "green";
    case "REJECTED": return "red";
    case "IN_PROGRESS": return "gold";
    default: return "blue";
  }
};

export default function AdminDemandeDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [demandeData, setDemandeData] = useState(null); // { demande, documents, transaction, payment }
  const [loading, setLoading] = useState(true);

  // Preview modal (PDF)
  const [previewVisible, setPreviewVisible] = useState(false);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [previewTitle, setPreviewTitle] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const res = await demandeService.getById(id);
      // attendu: { demande, documents, transaction, payment }
      setDemandeData(res);
    } catch (e) {
      message.error(e?.response?.data?.message || "Erreur de chargement");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [id]);

  const openDoc = async (docId, type = "original") => {
    try {
      // Votre backend supporte /documents/:id/content?type=original|traduit&disposition=inline
      const resp = await documentService.getContent(docId, { type, display: true });
      const blob = new Blob([resp.data], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      setPreviewUrl(url);
      setPreviewTitle(type === "traduit" ? "Document (traduit)" : "Document (original)");
      setPreviewVisible(true);
    } catch (e) {
      console.error(e);
      message.error("Impossible d’ouvrir le document");
    }
  };

  const downloadDoc = async (docId, type = "original") => {
    try {
      const resp = await documentService.getContent(docId, { type, display: false });
      const blob = new Blob([resp.data], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `document_${docId}_${type}.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
      message.error("Téléchargement impossible");
    }
  };

  const verifyIntegrity = async (docId) => {
    try {
      const r = await documentService.verifyIntegrity(docId);
      Modal.info({
        title: "Vérification d’intégrité",
        content: (
          <div>
            <div>
              Original :{" "}
              {r?.results?.original?.integrityOk ? (
                <Tag color="green">Valide</Tag>
              ) : (
                <Tag color="red">Invalide</Tag>
              )}
            </div>
            {r?.results?.traduit && (
              <div style={{ marginTop: 8 }}>
                Traduit :{" "}
                {r?.results?.traduit?.integrityOk ? (
                  <Tag color="green">Valide</Tag>
                ) : (
                  <Tag color="red">Invalide</Tag>
                )}
              </div>
            )}
            <div style={{ marginTop: 8 }}>
              Blockchain : {r?.chainValid ? <Tag color="blue">OK</Tag> : <Tag color="red">Non valide</Tag>}
            </div>
          </div>
        ),
      });
    } catch {
      message.error("Échec de vérification");
    }
  };

  if (loading || !demandeData?.demande) {
    return (
      <div className="flex items-center justify-center min-h-[40vh]">
        <Spin />
      </div>
    );
  }

  const d = demandeData.demande;
  const docs = demandeData.documents || [];

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <h5 className="text-lg font-semibold">Demande — Détail</h5>
          <Breadcrumb
            items={[
              { title: <Link to="/admin/dashboard">Dashboard</Link> },
              { title: <Link to="/admin/demandes">Demandes</Link> },
              { title: `#${d.code}` },
            ]}
          />
        </div>

        <div className="mb-4">
          <Button icon={<ArrowLeftOutlined />} onClick={() => navigate(-1)}>Retour</Button>
        </div>

        <Card>
         
          <Descriptions bordered column={2} title="Informations principales">
            <Descriptions.Item label="Code">
              <Space>
                <FileTextOutlined />
                <Tag color="blue">{d.code}</Tag>
              </Space>
            </Descriptions.Item>
            <Descriptions.Item label="Date">
              {d.dateDemande ? dayjs(d.dateDemande).format("DD/MM/YYYY HH:mm") : "—"}
            </Descriptions.Item>

            <Descriptions.Item label="Statut" span={2}>
              <Tag color={statusTagColor(d.status)}>{d.status || "PENDING"}</Tag>
            </Descriptions.Item>

            <Descriptions.Item label="Demandeur" span={2}>
              {d.user?.email} {d.user?.firstName || d.user?.lastName ? `— ${d.user?.firstName ?? ""} ${d.user?.lastName ?? ""}` : ""}
            </Descriptions.Item>

            <Descriptions.Item label="Organisation cible">
              {d.targetOrg ? (
                <Link to={`/admin/organisations/${d.targetOrg.id}`}>{d.targetOrg.name}</Link>
              ) : "—"}
            </Descriptions.Item>

            <Descriptions.Item label="Organisation traductrice">
              {d.assignedOrg ? (
                <Link to={`/admin/organisations/${d.assignedOrg.id}`}>{d.assignedOrg.name}</Link>
              ) : "—"}
            </Descriptions.Item>

            <Descriptions.Item label="Période">
              {d.periode || "—"}
            </Descriptions.Item>
            <Descriptions.Item label="Année">
              {d.year || "—"}
            </Descriptions.Item>

            <Descriptions.Item label="Observation" span={2}>
              {d.observation || "—"}
            </Descriptions.Item>
          </Descriptions>

          <Divider />

          <Tabs defaultActiveKey="acad">
            

            <TabPane tab="Académique" key="acad">
              <Descriptions bordered column={2}>
                <Descriptions.Item label="Série">{d.serie || "—"}</Descriptions.Item>
                <Descriptions.Item label="Niveau">{d.niveau || "—"}</Descriptions.Item>
                <Descriptions.Item label="Mention">{d.mention || "—"}</Descriptions.Item>
                <Descriptions.Item label="Année (scol.)">{d.annee || "—"}</Descriptions.Item>
                <Descriptions.Item label="Pays de l’école">{d.countryOfSchool || "—"}</Descriptions.Item>
                <Descriptions.Item label="Établissement">{d.secondarySchoolName || "—"}</Descriptions.Item>
                <Descriptions.Item label="Diplôme obtenu le" span={2}>
                  {d.graduationDate ? dayjs(d.graduationDate).format("DD/MM/YYYY") : "—"}
                </Descriptions.Item>
              </Descriptions>
            </TabPane>

            <TabPane tab="Identité" key="identite">
              <Descriptions bordered column={2}>
                <Descriptions.Item label="Date de naissance">
                  {d.dob ? dayjs(d.dob).format("DD/MM/YYYY") : "—"}
                </Descriptions.Item>
                <Descriptions.Item label="Nationalité">{d.citizenship || "—"}</Descriptions.Item>
                <Descriptions.Item label="Passeport" span={2}>{d.passport || "—"}</Descriptions.Item>
                <Descriptions.Item label="Anglais langue maternelle">
                  {d.isEnglishFirstLanguage ? "Oui" : "Non"}
                </Descriptions.Item>
                <Descriptions.Item label="Tests anglais (JSON)">
                  {d.englishProficiencyTests ? JSON.stringify(d.englishProficiencyTests) : "—"}
                </Descriptions.Item>
                <Descriptions.Item label="Scores">{d.testScores || "—"}</Descriptions.Item>
              </Descriptions>
            </TabPane>

            <TabPane tab="Financier & Visa" key="fin">
              <Descriptions bordered column={2}>
                <Descriptions.Item label="Aide financière">
                  {d.willApplyForFinancialAid ? "Oui" : "Non"}
                </Descriptions.Item>
                <Descriptions.Item label="Parrainage externe">
                  {d.hasExternalSponsorship ? "Oui" : "Non"}
                </Descriptions.Item>
                <Descriptions.Item label="Type de visa">{d.visaType || "—"}</Descriptions.Item>
                <Descriptions.Item label="A déjà étudié aux USA">
                  {d.hasPreviouslyStudiedInUS ? "Oui" : "Non"}
                </Descriptions.Item>
              </Descriptions>
            </TabPane>

            <TabPane tab="Essais" key="essais">
              <Descriptions bordered column={1}>
                <Descriptions.Item label="Personal statement">{d.personalStatement || "—"}</Descriptions.Item>
                <Descriptions.Item label="Optional essay">{d.optionalEssay || "—"}</Descriptions.Item>
                <Descriptions.Item label="Application round">{d.applicationRound || "—"}</Descriptions.Item>
                <Descriptions.Item label="Découverte">{d.howDidYouHearAboutUs || "—"}</Descriptions.Item>
              </Descriptions>
            </TabPane>

            
          </Tabs>
        </Card>

        {/* Preview modal */}
        <Modal
          open={previewVisible}
          title={previewTitle}
          onCancel={() => {
            if (previewUrl) URL.revokeObjectURL(previewUrl);
            setPreviewUrl(null);
            setPreviewVisible(false);
          }}
          footer={null}
          width="80%"
          bodyStyle={{ height: "70vh", overflow: "hidden" }}
        >
          {previewUrl ? (
            <iframe src={previewUrl} style={{ width: "100%", height: "100%", border: "none" }} title="Preview" />
          ) : (
            <Spin />
          )}
        </Modal>
      </div>
    </div>
  );
}
