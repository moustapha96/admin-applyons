// src/pages/Admin/Filieres/DepartmentFiliereCreate.jsx
"use client";
import { useParams, useNavigate, Link } from "react-router-dom";
import { Breadcrumb, Button, Card, Form, Input, Select, Space, message } from "antd";

import departmentService from "@/services/departmentService";

const DEPS_BASE = "/admin/departments";

export default function DepartmentFiliereCreate() {
  const { id: departmentId } = useParams();
  const navigate = useNavigate();
  const [form] = Form.useForm();

  const submit = async (values) => {
    try {
      const payload = {
        name: values.name?.trim(),
        code: values.code?.trim() || undefined,
        level: values.level || undefined,
        description: values.description?.trim() || undefined,
      };

      await departmentService.createFiliere(departmentId, payload); // 201 ; 409 si doublon
      message.success("Filière créée");
      navigate(`${DEPS_BASE}/${departmentId}/filieres`);
    } catch (e) {
      const msg = e?.response?.data?.message;
      if (e?.response?.status === 409) {
        message.error(msg || "Une filière avec ce nom existe déjà dans ce département");
      } else {
        message.error(msg || "Échec de création de la filière");
      }
    }
  };

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <h5 className="text-lg font-semibold">Filières du département</h5>
          <Breadcrumb
            items={[
              { title: <Link to="/admin/dashboard">Dashboard</Link> },
              { title: <Link to={DEPS_BASE}>Départements</Link> },
              { title: <Link to={`${DEPS_BASE}/${departmentId}`}>Détail</Link> },
              { title: <Link to={`${DEPS_BASE}/${departmentId}/filieres`}>Filières</Link> },
              { title: "Créer" },
            ]}
          />
        </div>

        <Card title="Nouvelle filière">
          <Form layout="vertical" form={form} onFinish={submit}>
            <Form.Item
              label="Nom"
              name="name"
              rules={[{ required: true, message: "Nom requis" }]}
            >
              <Input placeholder="Ex. Informatique" />
            </Form.Item>

            <Form.Item label="Code" name="code">
              <Input placeholder="Ex. INFO" />
            </Form.Item>

            <Form.Item label="Niveau" name="level">
              <Select
                allowClear
                placeholder="Sélectionner un niveau"
                options={[
                  { value: "Licence", label: "Licence" },
                  { value: "Master", label: "Master" },
                  { value: "Doctorat", label: "Doctorat" },
                ]}
              />
            </Form.Item>

            <Form.Item label="Description" name="description">
              <Input.TextArea rows={4} placeholder="Description (optionnel)" />
            </Form.Item>

            <Space>
              <Button onClick={() => navigate(-1)}>Annuler</Button>
              <Button type="primary" htmlType="submit">
                Créer
              </Button>
            </Space>
          </Form>
        </Card>
      </div>
    </div>
  );
}
