/* eslint-disable no-unused-vars */
/* eslint-disable react-hooks/exhaustive-deps */
// src/pages/Documents/DocumentsList.jsx
/* eslint-disable react/jsx-key */
"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
    Breadcrumb,
    Button,
    Card,
    DatePicker,
    Descriptions,
    Drawer,
    Input,
    List,
    Modal,
    Progress,
    Space,
    Table,
    Tag,
    Tooltip,
    message,
    Select,
} from "antd";
import {
    SearchOutlined,
    EyeOutlined,
    DownloadOutlined,
    CheckCircleOutlined,
    ExclamationCircleOutlined,
    DeleteOutlined,
    FileTextOutlined,
    FilePdfOutlined,
    LockOutlined,
    TranslationOutlined,
    InfoCircleOutlined,
    ReloadOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";
import documentService from "@/services/documentService";
import organizationService from "@/services/organizationService";

const { RangePicker } = DatePicker;
const { confirm } = Modal;

function payColor(b) { return b ? "purple" : undefined; }

export default function DocumentsList() {
    const [searchParams] = useSearchParams();
    // Optionnel: pré-filtrer par demande si on arrive depuis “Détail demande”
    const demandeFromUrl = searchParams.get("demandeId") || undefined;

    const [loading, setLoading] = useState(false);
    const [rows, setRows] = useState([]);
    const [orgs, setOrgs] = useState([]);

    const [pag, setPag] = useState({ current: 1, pageSize: 10, total: 0 });
    const [filters, setFilters] = useState({
        search: "",
        demandePartageId: demandeFromUrl,
        ownerOrgId: undefined,
        translated: undefined,  // true / false
        from: undefined,
        to: undefined,
    });

    // Preview modal
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewUrl, setPreviewUrl] = useState(null);
    const [previewTitle, setPreviewTitle] = useState("");

    // Drawer détail
    const [drawerOpen, setDrawerOpen] = useState(false);
    const [drawerDoc, setDrawerDoc] = useState(null);

    // Chargement des organisations (pour filtre Owner)
    useEffect(() => {
        (async () => {
            try {
                const res = await organizationService.list({ page: 1, limit: 500 });
                console.log(res);
                setOrgs(res?.organizations || []);
            } catch {
                // silencieux
            }
        })();
    }, []);

    const fetch = useCallback(async (page = pag.current, pageSize = pag.pageSize, f = filters) => {
        setLoading(true);
        try {
            const { documents, pagination } = await documentService.list({
                page,
                limit: pageSize,
                search: f.search || undefined,
                demandePartageId: f.demandePartageId || undefined,
                ownerOrgId: f.ownerOrgId || undefined,
                translated: typeof f.translated === "boolean" ? f.translated : undefined,
                from: f.from || undefined,
                to: f.to || undefined,
            });
            console.log(documents);
            setRows(documents || []);
            setPag({ current: page, pageSize, total: pagination?.total || 0 });
        } catch (e) {
            message.error(e?.response?.data?.message || "Erreur chargement des documents");
        } finally {
            setLoading(false);
        }
    }, [pag.current, pag.pageSize, filters]);

    useEffect(() => { fetch(1, pag.pageSize, filters); /* eslint-disable-next-line */ }, [
        filters.search, filters.demandePartageId, filters.ownerOrgId, filters.translated, filters.from, filters.to,
    ]);


    function normalizeUrl(u) {
        return u
    }


    const openUrl = (u) => {
        const url = normalizeUrl(u);
        if (!url) return message.warning("URL indisponible");
        window.open(url, "_blank", "noopener,noreferrer");
    };





    const removeDoc = (doc) => {
        confirm({
            title: "Supprimer ce document ?",
            icon: <ExclamationCircleOutlined />,
            content: "Cette action est irréversible.",
            okText: "Supprimer",
            okType: "danger",
            cancelText: "Annuler",
            onOk: async () => {
                try {
                    await documentService.remove(doc.id);
                    message.success("Document supprimé");
                    fetch();
                } catch (e) {
                    message.error(e?.response?.data?.message || "Suppression impossible");
                }
            },
        });
    };

    const columns = [

        {
            title: "Ajouté par (org.)",
            dataIndex: ["ownerOrg", "name"],
            width: 280,
            render: (_, r) =>
                r.ownerOrg ? (
                    <Space direction="vertical" size={0}>
                        <div>{r.ownerOrg.name}</div>
                        <div style={{ fontSize: 12, color: "#666" }}>
                            {r.ownerOrg.type} {r.ownerOrg.slug ? `• ${r.ownerOrg.slug}` : ""}
                        </div>
                    </Space>
                ) : (
                    <Tag>{r.ownerOrgId || "—"}</Tag>
                ),
        },
        {
            title: "Créé le",
            dataIndex: "createdAt",
            width: 160,
            render: (v) => (v ? dayjs(v).format("DD/MM/YYYY HH:mm") : "—"),
        },

        {
            title: "Actions",
            key: "actions",
            fixed: "right",
            width: 320,
            render: (_, r) => (
                <Space wrap>
                    <Tooltip title="Voir original">
                        <Button icon={<EyeOutlined />} onClick={() => openUrl(r.urlOriginal)} />
                    </Tooltip>

                    <Tooltip title="Voir traduit" placement="top" disabled={!r.estTraduit || !r.urlTraduit}>
                        <Button icon={<TranslationOutlined />} disabled={!r.estTraduit || !r.urlTraduit} onClick={() => openUrl(r.urlTraduit)} />
                    </Tooltip>
                    <Tooltip title="Détails">
                        <Button icon={<InfoCircleOutlined />} onClick={() => { setDrawerDoc(r); setDrawerOpen(true); }} />
                    </Tooltip>
                    <Tooltip title="Supprimer">
                        <Button danger icon={<DeleteOutlined />} onClick={() => removeDoc(r)} />
                    </Tooltip>
                </Space>
            ),
        },
    ];

    return (
        <div className="container-fluid relative px-3">
            <div className="layout-specing">
                <div className="md:flex justify-between items-center mb-6">
                    <h5 className="text-lg font-semibold">Documents</h5>
                    <Breadcrumb items={[{ title: <Link to="/admin/dashboard">Dashboard</Link> }, { title: "Documents" }]} />
                </div>

                <Card className="mb-4">
                    <Space wrap style={{ width: "100%", justifyContent: "space-between" }}>
                        <Space wrap>
                            <Input
                                allowClear
                                placeholder="Recherche (code ADN…)"
                                style={{ width: 260 }}
                                value={filters.search}
                                onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
                                onPressEnter={() => fetch()}
                                suffix={<SearchOutlined onClick={() => fetch()} style={{ color: "#aaa" }} />}
                            />
                            <Input
                                allowClear
                                placeholder="Par demande (ID)"
                                style={{ width: 240 }}
                                value={filters.demandePartageId}
                                onChange={(e) => setFilters((f) => ({ ...f, demandePartageId: e.target.value || undefined }))}
                            />
                            <Input
                                allowClear
                                placeholder="Par org. (ID)"
                                style={{ width: 200 }}
                                value={filters.ownerOrgId}
                                onChange={(e) => setFilters((f) => ({ ...f, ownerOrgId: e.target.value || undefined }))}
                            />
                            <Select
                                allowClear
                                placeholder="Traduit ?"
                                style={{ width: 140 }}
                                value={filters.translated}
                                onChange={(v) => setFilters((f) => ({ ...f, translated: v }))}
                                options={[
                                    { value: true, label: "Oui" },
                                    { value: false, label: "Non" },
                                ]}
                            />
                            <RangePicker
                                allowClear
                                onChange={(vals) => {
                                    const from = vals?.[0] ? vals[0].startOf("day").toISOString() : undefined;
                                    const to = vals?.[1] ? vals[1].endOf("day").toISOString() : undefined;
                                    setFilters((f) => ({ ...f, from, to }));
                                }}
                            />
                        </Space>

                        <Space>
                            <Button icon={<ReloadOutlined />} onClick={() => fetch()}>Rafraîchir</Button>
                        </Space>
                    </Space>
                </Card>

                <Table
                    rowKey="id"
                    dataSource={rows}
                    loading={loading}
                    columns={columns}
                    pagination={{
                        current: pag.current,
                        pageSize: pag.pageSize,
                        total: pag.total,
                        onChange: (p, ps) => fetch(p, ps, filters),
                        showSizeChanger: true,
                        pageSizeOptions: ["5", "10", "20", "50"],
                    }}
                    scroll={{ x: 1200 }}
                />

                {/* Drawer détail document */}
                <Drawer
                    title="Détails du document"
                    width={560}
                    open={drawerOpen}
                    onClose={() => setDrawerOpen(false)}
                    destroyOnHidden
                >
                    {drawerDoc ? (
                        <Descriptions bordered column={1} size="small">
                            <Descriptions.Item label="Ajouté par">
                                {drawerDoc.ownerOrg ? (
                                    <Space direction="vertical" size={0}>
                                        <span>{drawerDoc.ownerOrg.name}</span>
                                        <span style={{ fontSize: 12, color: "#666" }}>
                                            {drawerDoc.ownerOrg.type} {drawerDoc.ownerOrg.slug ? `• ${drawerDoc.ownerOrg.slug}` : ""}
                                        </span>
                                    </Space>
                                ) : (
                                    drawerDoc.ownerOrgId || "—"
                                )}
                            </Descriptions.Item>
                            <Descriptions.Item label="Statut traduction">
                                {drawerDoc.estTraduit ? <Tag color="green">Traduit</Tag> : <Tag>Non</Tag>}
                            </Descriptions.Item>
                            <Descriptions.Item label="Chiffré">
                                {drawerDoc.encryptedAt || drawerDoc.urlChiffre ? (
                                    <Tag color="purple" icon={<LockOutlined />}>Oui</Tag>
                                ) : (
                                    <Tag>Non</Tag>
                                )}
                            </Descriptions.Item>
                            <Descriptions.Item label="Created at">
                                {drawerDoc.createdAt ? dayjs(drawerDoc.createdAt).format("DD/MM/YYYY HH:mm") : "—"}
                            </Descriptions.Item>
                            <Descriptions.Item label="Encrypted at">
                                {drawerDoc.encryptedAt ? dayjs(drawerDoc.encryptedAt).format("DD/MM/YYYY HH:mm") : "—"}
                            </Descriptions.Item>
                            <Descriptions.Item label="Actions rapides">
                                <Space wrap>
                                    <Button icon={<EyeOutlined />} onClick={() => openUrl(drawerDoc.urlOriginal)}>Voir original</Button>
                                    <Button icon={<TranslationOutlined />} disabled={!drawerDoc.estTraduit || !drawerDoc.urlTraduit}
                                        onClick={() => openUrl(drawerDoc.urlTraduit)}>Voir traduit</Button>
                                   </Space>
                            </Descriptions.Item>
                        </Descriptions>
                    ) : null}
                </Drawer>

                {/* Modal preview */}
                <Modal
                    title={previewTitle || "Document"}
                    open={previewOpen}
                    onCancel={() => {
                        setPreviewOpen(false);
                        if (previewUrl) URL.revokeObjectURL(previewUrl);
                        setPreviewUrl(null);
                    }}
                    footer={null}
                    width="80%"
                    bodyStyle={{ height: "70vh", overflow: "hidden" }}
                    destroyOnClose
                >
                    {previewUrl ? (
                        <iframe src={previewUrl} style={{ width: "100%", height: "100%", border: "none" }} title="preview" />
                    ) : (
                        <List
                            dataSource={[1]}
                            renderItem={() => (
                                <List.Item>
                                    <Space>
                                        <FileTextOutlined />
                                        Chargement…
                                    </Space>
                                    <Progress percent={60} status="active" />
                                </List.Item>
                            )}
                        />
                    )}
                </Modal>
            </div>
        </div>
    );
}
