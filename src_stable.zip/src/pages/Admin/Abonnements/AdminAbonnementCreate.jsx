/* eslint-disable react/no-unescaped-entities */
// src/pages/Admin/Abonnements/AdminAbonnementCreate.jsx
/* eslint-disable no-unused-vars */
"use client";
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Form,
  InputNumber,
  Button,
  Select,
  Card,
  Breadcrumb,
  Row,
  Col,
  message,
  DatePicker,
  Alert,
  Typography,
} from "antd";
import {
  SaveOutlined,
  ArrowLeftOutlined,
  DollarOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";

import organizationService from "@/services/organizationService";
import abonnementService from "@/services/abonnement.service";

const { Title } = Typography;
const { RangePicker } = DatePicker;

export default function AdminAbonnementCreate() {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [organizations, setOrganizations] = useState([]);
  const [fetchingOrgs, setFetchingOrgs] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    document.documentElement.setAttribute("dir", "ltr");
    document.documentElement.classList.add("light");
    document.documentElement.classList.remove("dark");
    fetchOrganizations();
  }, []);

  const fetchOrganizations = async () => {
    setFetchingOrgs(true);
    try {
      const response = await organizationService.list({ limit: 1000 });
      setOrganizations(response.organizations || []);
    } catch (error) {
      console.error("Erreur organisations:", error);
      message.error("Erreur lors de la récupération des organisations");
    } finally {
      setFetchingOrgs(false);
    }
  };

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      const payload = {
        organizationId: values.organizationId,
        dateDebut: values.periode?.[0]?.format("YYYY-MM-DD"),
        dateExpiration: values.periode?.[1]?.format("YYYY-MM-DD"),
        montant: Number(values.montant),
      };

      const response = await abonnementService.create(payload);
      message.success("Abonnement créé avec succès");
      navigate(`/admin/abonnements/${response.abonnement.id}/details`);
    } catch (error) {
      console.error("Erreur création abonnement:", error);
      message.error(
        error?.response?.data?.message ||
          "Échec de la création de l'abonnement. Vérifiez les dates et le montant."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <Title level={4}>Créer un nouvel abonnement</Title>
          <Breadcrumb
            items={[
              { title: <Link to="/admin">Tableau de bord</Link> },
              { title: <Link to="/admin/abonnements">Abonnements</Link> },
              { title: "Nouvel abonnement" },
            ]}
          />
        </div>

        <Card>
          <Alert
            message="Informations importantes"
            description={
              <ul className="list-disc pl-5">
                <li>
                  Les dates ne doivent pas se chevaucher avec un abonnement existant
                  pour la même organisation.
                </li>
                <li>Le montant doit être un nombre positif.</li>
                <li>L'organisation doit être active.</li>
              </ul>
            }
            type="info"
            showIcon
            className="mb-6"
          />

          <Form form={form} layout="vertical" onFinish={handleSubmit}>
            <Row gutter={16}>
              <Col span={24}>
                <Form.Item
                  name="organizationId"
                  label="Organisation"
                  rules={[{ required: true, message: "L'organisation est obligatoire" }]}
                >
                  <Select
                    placeholder="Sélectionner une organisation"
                    loading={fetchingOrgs}
                    showSearch
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                      String(option?.children ?? "")
                        .toLowerCase()
                        .includes(input.toLowerCase())
                    }
                  >
                    {organizations.map((org) => (
                      <Select.Option key={org.id} value={org.id}>
                        {org.name} ({org.type})
                      </Select.Option>
                    ))}
                  </Select>
                </Form.Item>
              </Col>

              <Col span={24}>
                <Form.Item
                  name="periode"
                  label="Période d'abonnement"
                  rules={[{ required: true, message: "La période est obligatoire" }]}
                >
                  <RangePicker
                    format="YYYY-MM-DD"
                    className="w-full"
                    disabledDate={(current) =>
                      current && current < dayjs().startOf("day")
                    }
                  />
                </Form.Item>
              </Col>

              <Col span={24}>
                <Form.Item
                  name="montant"
                  label="Montant (USD)"
                  rules={[
                    { required: true, message: "Le montant est obligatoire" },
                    { type: "number", min: 0, message: "Le montant doit être positif" },
                  ]}
                >
                  <InputNumber
                    min={0}
                    step={100}
                    className="w-full"
                    addonAfter="USD"
                    prefix={<DollarOutlined />}
                  />
                </Form.Item>
              </Col>

              <Col span={24} className="text-right mt-6">
                <Button onClick={() => navigate(-1)} icon={<ArrowLeftOutlined />}>
                  Annuler
                </Button>
                <Button
                  className="ml-2"
                  type="primary"
                  htmlType="submit"
                  icon={<SaveOutlined />}
                  loading={loading}
                >
                  {loading ? "Création en cours..." : "Créer l'abonnement"}
                </Button>
              </Col>
            </Row>
          </Form>
        </Card>
      </div>
    </div>
  );
}
