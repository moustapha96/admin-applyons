import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Table,
  Tag,
  Space,
  Breadcrumb,
  Button,
  Input,
  Select,
  message,
  Card,
  Typography,
  DatePicker,
  Alert
} from "antd";
import {
  SearchOutlined,
  CalendarOutlined,
  BellOutlined
} from "@ant-design/icons";
import abonnementService from "../../services/abonnementService";
import organizationService from "../../../services/organizationservice";
// import { useAuth } from "../../../hooks/useAuth";

const { Title } = Typography;
const { Search } = Input;
const { RangePicker } = DatePicker;

const AdminAbonnementsExpiringSoon = () => {
  // const { user } = useAuth();
  const [abonnements, setAbonnements] = useState([]);
  const [organizations, setOrganizations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    days: 30,
    organizationId: null,
  });
  const navigate = useNavigate();

  useEffect(() => {
    document.documentElement.setAttribute("dir", "ltr");
    document.documentElement.classList.add("light");
    document.documentElement.classList.remove("dark");
    fetchAbonnements();
    fetchOrganizations();
  }, [filters]);

  const fetchAbonnements = async () => {
    setLoading(true);
    try {
      const params = {
        days: filters.days,
        ...(filters.organizationId && { organizationId: filters.organizationId }),
      };
      const response = await abonnementService.expiringSoon(params);
      setAbonnements(response.abonnements);
    } catch (error) {
      console.error("Erreur lors de la récupération des abonnements:", error);
      message.error("Erreur lors de la récupération des abonnements");
    } finally {
      setLoading(false);
    }
  };

  const fetchOrganizations = async () => {
    try {
      const response = await organizationService.list({ limit: 1000 });
      setOrganizations(response.organizations);
    } catch (error) {
      console.error("Erreur lors de la récupération des organisations:", error);
    }
  };

  const handleFilterChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const getDaysUntilExpiration = (dateExpiration) => {
    const now = new Date();
    const end = new Date(dateExpiration);
    const diffTime = end - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const columns = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
      render: (id) => `#${id.substring(0, 8)}...`,
    },
    {
      title: "Organisation",
      dataIndex: ["organization", "name"],
      key: "organization",
      render: (name, record) => (
        <Link to={`/admin/organisations/${record.organizationId}/details`}>
          {name}
        </Link>
      ),
    },
    {
      title: "Date d'expiration",
      dataIndex: "dateExpiration",
      key: "dateExpiration",
      render: (dateExpiration) => (
        <Space>
          <CalendarOutlined />
          {new Date(dateExpiration).toLocaleDateString()}
          <Tag color={getDaysUntilExpiration(dateExpiration) <= 7 ? "red" : "orange"}>
            {getDaysUntilExpiration(dateExpiration)} jours
          </Tag>
        </Space>
      ),
    },
    {
      title: "Montant",
      dataIndex: "montant",
      key: "montant",
      render: (montant) => `${parseFloat(montant).toLocaleString()} USD`,
    },
    {
      title: "Actions",
      key: "actions",
      render: (_, record) => (
        <Space size="middle">
          <Button type="link" size="small">
            <Link to={`/admin/abonnements/${record.id}/details`}>Détails</Link>
          </Button>
          <Button
            type="link"
            size="small"
            onClick={() => navigate(`/admin/abonnements/${record.id}/renew`)}
          >
            Renouveler
          </Button>
        </Space>
      ),
    },
  ];

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <Title level={4}>
            <BellOutlined className="mr-2" />
            Abonnements expirant bientôt
          </Title>
          <Breadcrumb
            items={[
              { title: <Link to="/admin">Tableau de bord</Link> },
              { title: "Abonnements expirant bientôt" },
            ]}
          />
        </div>

        <Alert
          message={`Abonnements expirant dans les ${filters.days} prochains jours`}
          type="warning"
          showIcon
          className="mb-6"
        />

        <Card className="mb-6">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <div className="w-full md:w-1/3">
              <Select
                placeholder="Filtrer par organisation"
                allowClear
                className="w-full"
                onChange={(value) => handleFilterChange("organizationId", value)}
                options={organizations.map(org => ({
                  value: org.id,
                  label: org.name,
                }))}
              />
            </div>
            <div className="w-full md:w-1/3">
              <Input
                type="number"
                addonBefore="Jours"
                placeholder="Nombre de jours"
                value={filters.days}
                onChange={(e) => handleFilterChange("days", e.target.value)}
                min={1}
              />
            </div>
            <div className="w-full md:w-1/3 text-right">
              <Button
                type="primary"
                icon={<SearchOutlined />}
                onClick={fetchAbonnements}
              >
                Actualiser
              </Button>
            </div>
          </div>
        </Card>

        <Card>
          <Table
            columns={columns}
            dataSource={abonnements}
            loading={loading}
            rowKey="id"
            pagination={false}
            scroll={{ x: true }}
          />
        </Card>
      </div>
    </div>
  );
};

export default AdminAbonnementsExpiringSoon;
