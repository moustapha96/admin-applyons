/* eslint-disable react/no-unescaped-entities */
// src/pages/Admin/Abonnements/AdminAbonnementRenew.jsx
/* eslint-disable no-unused-vars */
"use client";

import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  Form,
  InputNumber,
  Button,
  Card,
  Breadcrumb,
  Row,
  Col,
  message,
  DatePicker,
  Spin,
  Alert,
  Typography,
  Descriptions,
} from "antd";
import { ArrowLeftOutlined, DollarOutlined, ReloadOutlined } from "@ant-design/icons";
import dayjs from "dayjs";

import abonnementService from "@/services/abonnement.service";

const { Title, Text } = Typography;
const { RangePicker } = DatePicker;

export default function AdminAbonnementRenew() {
  const { id } = useParams();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(true);
  const [abonnement, setAbonnement] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    document.documentElement.setAttribute("dir", "ltr");
    document.documentElement.classList.add("light");
    document.documentElement.classList.remove("dark");
    fetchAbonnement();
  }, [id]);

  const fetchAbonnement = async () => {
    setLoading(true);
    try {
      const response = await abonnementService.getById(id, { withOrg: "true" });
      const abo = response.abonnement;
      setAbonnement(abo);

      form.setFieldsValue({
        periode: [dayjs(abo.dateExpiration), dayjs(abo.dateExpiration).add(1, "year")],
        montant: Number(abo.montant),
      });
    } catch (error) {
      console.error("Erreur abonnement:", error);
      message.error("Erreur lors de la récupération de l'abonnement");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      const payload = {
        dateDebut: values.periode?.[0]?.format("YYYY-MM-DD"),
        dateExpiration: values.periode?.[1]?.format("YYYY-MM-DD"),
        montant: Number(values.montant),
      };

      const response = await abonnementService.renew(id, payload);
      message.success("Abonnement renouvelé avec succès");
      navigate(`/admin/abonnements/${response.abonnement.id}/details`);
    } catch (error) {
      console.error("Erreur renouvellement:", error);
      message.error(
        error?.response?.data?.message ||
          "Échec du renouvellement. Vérifiez les dates et le montant."
      );
    } finally {
      setLoading(false);
    }
  };

  if (loading || !abonnement) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <Title level={4}>
            Renouveler l'abonnement #{abonnement.id.substring(0, 8)}…
          </Title>
          <Breadcrumb
            items={[
              { title: <Link to="/admin">Tableau de bord</Link> },
              { title: <Link to="/admin/abonnements">Abonnements</Link> },
              { title: "Renouveler" },
            ]}
          />
        </div>

        <Card className="mb-6">
          <Descriptions title="Abonnement actuel" bordered>
            <Descriptions.Item label="Organisation" span={2}>
              <Text>{abonnement.organization?.name}</Text>
            </Descriptions.Item>
            <Descriptions.Item label="Période actuelle">
              {dayjs(abonnement.dateDebut).format("DD/MM/YYYY")} →
              {dayjs(abonnement.dateExpiration).format("DD/MM/YYYY")}
            </Descriptions.Item>
            <Descriptions.Item label="Montant actuel">
              {Number(abonnement.montant).toLocaleString()} USD
            </Descriptions.Item>
          </Descriptions>
        </Card>

        <Card>
          <Alert
            message="Renouvellement"
            description="Définissez la nouvelle période et le montant. La nouvelle période doit commencer après la fin de l'abonnement actuel."
            type="info"
            showIcon
            className="mb-6"
          />

          <Form form={form} layout="vertical" onFinish={handleSubmit}>
            <Row gutter={16}>
              <Col span={24}>
                <Form.Item
                  name="periode"
                  label="Nouvelle période"
                  rules={[{ required: true, message: "La période est obligatoire" }]}
                >
                  <RangePicker
                    format="YYYY-MM-DD"
                    className="w-full"
                    disabledDate={(current) =>
                      current && current < dayjs(abonnement.dateExpiration).startOf("day")
                    }
                  />
                </Form.Item>
              </Col>

              <Col span={24}>
                <Form.Item
                  name="montant"
                  label="Nouveau montant (USD)"
                  rules={[
                    { required: true, message: "Le montant est obligatoire" },
                    { type: "number", min: 0, message: "Le montant doit être positif" },
                  ]}
                >
                  <InputNumber
                    min={0}
                    step={100}
                    className="w-full"
                    addonAfter="USD"
                    prefix={<DollarOutlined />}
                  />
                </Form.Item>
              </Col>

              <Col span={24} className="text-right mt-6">
                <Button onClick={() => navigate(-1)} icon={<ArrowLeftOutlined />}>
                  Annuler
                </Button>
                <Button
                  className="ml-2"
                  type="primary"
                  htmlType="submit"
                  icon={<ReloadOutlined />}
                  loading={loading}
                >
                  {loading ? "Renouvellement en cours..." : "Renouveler l'abonnement"}
                </Button>
              </Col>
            </Row>
          </Form>
        </Card>
      </div>
    </div>
  );
}
