/* eslint-disable react/no-unescaped-entities */
// src/pages/Admin/Abonnements/AdminAbonnementEdit.jsx
/* eslint-disable no-unused-vars */
"use client";

import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  Form,
  InputNumber,
  Button,
  Select,
  Card,
  Breadcrumb,
  Row,
  Col,
  message,
  DatePicker,
  Spin,
  Alert,
  Typography,
  Descriptions,
  Tag,
} from "antd";
import {
  SaveOutlined,
  ArrowLeftOutlined,
  DollarOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";

import organizationService from "@/services/organizationService";
import abonnementService from "@/services/abonnement.service";

const { Title, Text } = Typography;
const { Option } = Select;
const { RangePicker } = DatePicker;

export default function AdminAbonnementEdit() {
  const { id } = useParams();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(true);
  const [abonnement, setAbonnement] = useState(null);
  const [organizations, setOrganizations] = useState([]);
  const [fetchingOrgs, setFetchingOrgs] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    document.documentElement.setAttribute("dir", "ltr");
    document.documentElement.classList.add("light");
    document.documentElement.classList.remove("dark");
    fetchAbonnement();
    fetchOrganizations();
  }, [id]);

  const fetchAbonnement = async () => {
    setLoading(true);
    try {
      const response = await abonnementService.getById(id, { withOrg: "true" });
      const abo = response.abonnement;
      setAbonnement(abo);

      form.setFieldsValue({
        organizationId: abo.organizationId,
        periode: [dayjs(abo.dateDebut), dayjs(abo.dateExpiration)],
        montant: Number(abo.montant),
      });
    } catch (error) {
      console.error("Erreur abonnement:", error);
      message.error("Erreur lors de la récupération de l'abonnement");
    } finally {
      setLoading(false);
    }
  };

  const fetchOrganizations = async () => {
    setFetchingOrgs(true);
    try {
      const response = await organizationService.list({ limit: 1000 });
      setOrganizations(response.organizations || []);
    } catch (error) {
      console.error("Erreur organisations:", error);
      message.error("Erreur lors de la récupération des organisations");
    } finally {
      setFetchingOrgs(false);
    }
  };

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      const payload = {
        dateDebut: values.periode?.[0]?.format("YYYY-MM-DD"),
        dateExpiration: values.periode?.[1]?.format("YYYY-MM-DD"),
        montant: Number(values.montant),
      };

      const response = await abonnementService.update(id, payload);
      message.success("Abonnement mis à jour avec succès");
      navigate(`/admin/abonnements/${response.abonnement.id}/details`);
    } catch (error) {
      console.error("Erreur mise à jour:", error);
      message.error(
        error?.response?.data?.message ||
          "Échec de la mise à jour. Vérifiez les dates et le montant."
      );
    } finally {
      setLoading(false);
    }
  };

  if (loading || !abonnement) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const isExpired = dayjs(abonnement.dateExpiration).isBefore(dayjs(), "day");

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <Title level={4}>
            Modifier l'abonnement #{abonnement.id.substring(0, 8)}…
          </Title>
          <Breadcrumb
            items={[
              { title: <Link to="/admin">Tableau de bord</Link> },
              { title: <Link to="/admin/abonnements">Abonnements</Link> },
              { title: "Modifier" },
            ]}
          />
        </div>

        <Card className="mb-6">
          <Descriptions title="Informations actuelles" bordered>
            <Descriptions.Item label="Organisation" span={2}>
              <Text strong>{abonnement.organization?.name}</Text>
            </Descriptions.Item>
            <Descriptions.Item label="Créé le">
              {dayjs(abonnement.createdAt).format("DD/MM/YYYY HH:mm")}
            </Descriptions.Item>
            <Descriptions.Item label="Statut">
              {isExpired ? <Tag color="red">Expiré</Tag> : <Tag color="green">Actif</Tag>}
            </Descriptions.Item>
          </Descriptions>
        </Card>

        <Card>
          <Alert
            message="Attention"
            description="La modification des dates peut entraîner des chevauchements avec d'autres abonnements."
            type="warning"
            showIcon
            className="mb-6"
          />

          <Form
            form={form}
            layout="vertical"
            onFinish={handleSubmit}
            initialValues={{
              organizationId: abonnement.organizationId,
              periode: [dayjs(abonnement.dateDebut), dayjs(abonnement.dateExpiration)],
              montant: Number(abonnement.montant),
            }}
          >
            <Row gutter={16}>
              <Col span={24}>
                <Form.Item
                  name="organizationId"
                  label="Organisation"
                  rules={[{ required: true, message: "L'organisation est obligatoire" }]}
                >
                  <Select
                    placeholder="Sélectionner une organisation"
                    loading={fetchingOrgs}
                    showSearch
                    optionFilterProp="children"
                    filterOption={(input, option) =>
                      String(option?.children ?? "")
                        .toLowerCase()
                        .includes(input.toLowerCase())
                    }
                    disabled
                  >
                    {organizations.map((org) => (
                      <Option key={org.id} value={org.id}>
                        {org.name} ({org.type})
                      </Option>
                    ))}
                  </Select>
                </Form.Item>
              </Col>

              <Col span={24}>
                <Form.Item
                  name="periode"
                  label="Période d'abonnement"
                  rules={[{ required: true, message: "La période est obligatoire" }]}
                >
                  <RangePicker
                    format="YYYY-MM-DD"
                    className="w-full"
                    disabledDate={(current) => current && current < dayjs().startOf("day")}
                  />
                </Form.Item>
              </Col>

              <Col span={24}>
                <Form.Item
                  name="montant"
                  label="Montant (USD)"
                  rules={[
                    { required: true, message: "Le montant est obligatoire" },
                    { type: "number", min: 0, message: "Le montant doit être positif" },
                  ]}
                >
                  <InputNumber
                    min={0}
                    step={100}
                    className="w-full"
                    addonAfter="USD"
                    prefix={<DollarOutlined />}
                  />
                </Form.Item>
              </Col>

              <Col span={24} className="text-right mt-6">
                <Button onClick={() => navigate(-1)} icon={<ArrowLeftOutlined />}>
                  Annuler
                </Button>
                <Button
                  className="ml-2"
                  type="primary"
                  htmlType="submit"
                  icon={<SaveOutlined />}
                  loading={loading}
                >
                  {loading ? "Mise à jour en cours..." : "Mettre à jour"}
                </Button>
              </Col>
            </Row>
          </Form>
        </Card>
      </div>
    </div>
  );
}
