/* eslint-disable react/no-unescaped-entities */
// src/pages/Admin/Abonnements/AdminAbonnementDetails.jsx
/* eslint-disable no-unused-vars */
"use client";
import { useEffect, useState } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import {
  Breadcrumb,
  Card,
  Descriptions,
  Button,
  Space,
  Tag,
  Spin,
  Typography,
  Divider,
  Timeline,
  Modal,
  message,
  Form,
  InputNumber,
  Alert,
  DatePicker,
} from "antd";
import {
  ArrowLeftOutlined,
  CalendarOutlined,
  DollarOutlined,
  ExclamationCircleOutlined,
  HistoryOutlined,
  ReloadOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";
import abonnementService from "@/services/abonnement.service";

const { Title, Text } = Typography;
const { confirm } = Modal;
const { RangePicker } = DatePicker;

export default function AdminAbonnementDetails() {
  const { id } = useParams();
  const [abonnement, setAbonnement] = useState(null);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [renewModalVisible, setRenewModalVisible] = useState(false);
  const [renewForm] = Form.useForm();
  const navigate = useNavigate();

  useEffect(() => {
    document.documentElement.setAttribute("dir", "ltr");
    document.documentElement.classList.add("light");
    document.documentElement.classList.remove("dark");
    fetchAbonnement();
  }, [id]);

  const fetchAbonnement = async () => {
    setLoading(true);
    try {
      const response = await abonnementService.getById(id, {
        withOrg: "true",
        withPayments: "true",
      });
      setAbonnement(response.abonnement);
      setPayments(response.abonnement?.payments || []);
    } catch (error) {
      console.error("Erreur abonnement:", error);
      message.error("Erreur lors de la récupération de l'abonnement");
    } finally {
      setLoading(false);
    }
  };

  const handleRenew = async (values) => {
    setLoading(true);
    try {
      const payload = {
        dateDebut: values.periode?.[0]?.format("YYYY-MM-DD"),
        dateExpiration: values.periode?.[1]?.format("YYYY-MM-DD"),
        montant: Number(values.montant),
      };
      const response = await abonnementService.renew(id, payload);
      message.success("Abonnement renouvelé avec succès");
      setRenewModalVisible(false);
      navigate(`/admin/abonnements/${response.abonnement.id}/details`);
    } catch (error) {
      console.error("Erreur renouvellement:", error);
      message.error(
        error?.response?.data?.message ||
          "Échec du renouvellement. Vérifiez les dates et le montant."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleArchive = async () => {
    confirm({
      title: "Archiver cet abonnement ?",
      icon: <ExclamationCircleOutlined />,
      content:
        "Cette action est réversible. L'abonnement ne sera plus visible mais pourra être restauré.",
      okText: "Archiver",
      okType: "danger",
      cancelText: "Annuler",
      onOk: async () => {
        try {
          await abonnementService.softDelete(id);
          message.success("Abonnement archivé avec succès");
          navigate("/admin/abonnements");
        } catch (error) {
          console.error("Erreur archivage:", error);
          message.error("Échec de l'archivage");
        }
      },
    });
  };

  const handleDelete = async () => {
    confirm({
      title: "Supprimer définitivement cet abonnement ?",
      icon: <ExclamationCircleOutlined />,
      content:
        "Cette action est irréversible. Toutes les données seront perdues.",
      okText: "Supprimer",
      okType: "danger",
      cancelText: "Annuler",
      onOk: async () => {
        try {
          await abonnementService.hardDelete(id);
          message.success("Abonnement supprimé définitivement");
          navigate("/admin/abonnements");
        } catch (error) {
          console.error("Erreur suppression:", error);
          message.error("Échec de la suppression");
        }
      },
    });
  };

  const getStatusTag = () => {
    const now = dayjs();
    const start = dayjs(abonnement.dateDebut);
    const end = dayjs(abonnement.dateExpiration);

    if (end.isBefore(now, "day")) return <Tag color="red">Expiré</Tag>;
    if (start.isBefore(now, "day") && end.isAfter(now, "day"))
      return <Tag color="green">Actif</Tag>;
    return <Tag color="gold">À venir</Tag>;
  };

  if (loading || !abonnement) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <Title level={4}>
            Détails de l'abonnement #{abonnement.id.substring(0, 8)}…
          </Title>
          <Breadcrumb
            items={[
              { title: <Link to="/admin">Tableau de bord</Link> },
              { title: <Link to="/admin/abonnements">Abonnements</Link> },
              { title: "Détails" },
            ]}
          />
        </div>

        <div className="md:flex md:justify-end justify-end items-center mb-6">
          <Button onClick={() => navigate(-1)} icon={<ArrowLeftOutlined />}>
            Retour
          </Button>
        </div>

        {/* Infos abonnement */}
        <Card className="mb-6">
          <Descriptions title="Informations de l'abonnement" bordered column={1}>
            <Descriptions.Item label="ID">
              <Text copyable>{abonnement.id}</Text>
            </Descriptions.Item>

            {abonnement.organization && (
              <Descriptions.Item label="Organisation">
                <Link to={`/admin/organisations/${abonnement.organization.id}/details`}>
                  {abonnement.organization.name}
                </Link>
              </Descriptions.Item>
            )}

            <Descriptions.Item label="Période">
              <Space>
                <CalendarOutlined />
                {dayjs(abonnement.dateDebut).format("DD/MM/YYYY")} →
                {dayjs(abonnement.dateExpiration).format("DD/MM/YYYY")}
              </Space>
            </Descriptions.Item>

            <Descriptions.Item label="Statut">{getStatusTag()}</Descriptions.Item>

            <Descriptions.Item label="Montant">
              <Space>
                <DollarOutlined />
                {Number(abonnement.montant).toLocaleString()} USD
              </Space>
            </Descriptions.Item>

            <Descriptions.Item label="Créé le">
              {dayjs(abonnement.createdAt).format("DD/MM/YYYY HH:mm")}
            </Descriptions.Item>
            <Descriptions.Item label="Mis à jour le">
              {dayjs(abonnement.updatedAt).format("DD/MM/YYYY HH:mm")}
            </Descriptions.Item>
          </Descriptions>
        </Card>

        {/* Paiements (facultatif) */}
        {payments.length > 0 && (
          <Card className="mb-6">
            <Title level={5} className="mb-4">
              Historique des paiements
            </Title>
            <Timeline>
              {payments.map((p) => (
                <Timeline.Item
                  key={p.id}
                  color={p.status === "COMPLETED" || p.status === "PAID" ? "green" : "gray"}
                >
                  <Space direction="vertical" size="small">
                    <Text strong>
                      {dayjs(p.createdAt).format("DD/MM/YYYY HH:mm")}
                    </Text>
                    <Text>
                      {p.amount} {p.currency} via {p.provider}
                      {p.providerRef ? ` (Ref: ${p.providerRef})` : ""}
                    </Text>
                    <Tag color={p.status === "COMPLETED" || p.status === "PAID" ? "green" : "gold"}>
                      {p.status}
                    </Tag>
                  </Space>
                </Timeline.Item>
              ))}
            </Timeline>
          </Card>
        )}

        {/* Actions */}
        <Card>
          <Title level={5} className="mb-4">
            <HistoryOutlined className="mr-2" />
            Actions
          </Title>
          <Space size="middle">
            <Button
              type="primary"
              icon={<ReloadOutlined />}
              onClick={() => setRenewModalVisible(true)}
            >
              Renouveler
            </Button>
            <Button
              icon={<ArrowLeftOutlined />}
              onClick={() => navigate(`/admin/abonnements/${id}/edit`)}
            >
              Modifier
            </Button>
            {!abonnement.isDeleted ? (
              <Button danger icon={<ExclamationCircleOutlined />} onClick={handleArchive}>
                Archiver
              </Button>
            ) : (
              <>
                <Button
                  onClick={() =>
                    abonnementService.restore(id).then(() => {
                      message.success("Abonnement restauré");
                      fetchAbonnement();
                    })
                  }
                >
                  Restaurer
                </Button>
                <Button danger onClick={handleDelete}>
                  Supprimer définitivement
                </Button>
              </>
            )}
          </Space>
        </Card>

        {/* Modal de renouvellement */}
        <Modal
          title="Renouveler l'abonnement"
          open={renewModalVisible}
          onCancel={() => setRenewModalVisible(false)}
          footer={null}
          width={600}
          destroyOnClose
        >
          <Form
            form={renewForm}
            layout="vertical"
            onFinish={handleRenew}
            initialValues={{
              periode: [
                dayjs(abonnement.dateExpiration),
                dayjs(abonnement.dateExpiration).add(1, "year"),
              ],
              montant: Number(abonnement.montant),
            }}
          >
            <Alert
              message="Renouvellement"
              description="Définissez la nouvelle période et le montant pour le renouvellement."
              type="info"
              showIcon
              className="mb-4"
            />

            <Form.Item
              name="periode"
              label="Nouvelle période"
              rules={[{ required: true, message: "La période est obligatoire" }]}
            >
              <RangePicker
                format="YYYY-MM-DD"
                className="w-full"
                disabledDate={(current) =>
                  current && current < dayjs(abonnement.dateExpiration).startOf("day")
                }
              />
            </Form.Item>

            <Form.Item
              name="montant"
              label="Nouveau montant (USD)"
              rules={[
                { required: true, message: "Le montant est obligatoire" },
                { type: "number", min: 0, message: "Le montant doit être positif" },
              ]}
            >
              <InputNumber
                min={0}
                step={100}
                className="w-full"
                addonAfter="USD"
                prefix={<DollarOutlined />}
              />
            </Form.Item>

            <Divider />
            <Space className="w-full justify-end">
              <Button onClick={() => setRenewModalVisible(false)}>Annuler</Button>
              <Button type="primary" htmlType="submit" icon={<ReloadOutlined />} loading={loading}>
                {loading ? "Renouvellement en cours..." : "Renouveler"}
              </Button>
            </Space>
          </Form>
        </Modal>
      </div>
    </div>
  );
}
