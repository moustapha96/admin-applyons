import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Breadcrumb, Card, Descriptions, Avatar, Statistic, Row, Col, Divider, Tag, Space, Button, Spin } from "antd";
import { UserOutlined, MailOutlined, PhoneOutlined, EditFilled } from "@ant-design/icons";
import userService from "../../../services/userService";

import {  getPermissionColor, getPermissionLabel } from "../../../auth/permissions"
import { PERMS } from "../../../auth/permissions";

const UserDetail = () => {
    const { id } = useParams();
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        document.documentElement.setAttribute("dir", "ltr");
        document.documentElement.classList.add("light");
        document.documentElement.classList.remove("dark");
        fetchUserDetails(id);
    }, [id]);

    const fetchUserDetails = async (userId) => {
        setLoading(true);
        try {
            const response = await userService.getById(userId);
            console.log(response);
            setUser(response.user);
        } catch (error) {
            console.error("Erreur lors de la récupération de l'utilisateur:", error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <div className="flex items-center justify-center min-h-screen"><Spin size="large" /></div>;
    if (!user) return <div>Utilisateur non trouvé.</div>;

    return (
        <div className="container-fluid relative px-3">
            <div className="layout-specing">
                <div className="md:flex justify-between items-center mb-6">
                    <h5 className="text-lg font-semibold">Détails de l'utilisateur</h5>
                    <Breadcrumb
                        items={[
                            { title: <Link to="/admin/dashboard">Dashboard</Link> },
                            { title: <Link to="/admin/users">Liste des utilisateurs</Link> },
                            { title: `${user.firstName || ""} ${user.lastName || ""}` },
                        ]}
                    />
                </div>
                <div className="md:flex md:justify-end justify-end items-center mb-6">
                    <Button
                        type="primary"
                        onClick={() => navigate(`/admin/users/${user.id}/edit`)}
                        icon={<EditFilled />}
                    >
                        Modifier
                    </Button>
                </div>
                <Card>
                    <Descriptions title="Informations personnelles" bordered>
                        <Descriptions.Item label="Nom complet" span={2}>
                            <Avatar size="large" icon={<UserOutlined />} src={user.avatar} />
                            <span className="ml-3">{user.firstName || ""} {user.lastName || ""}</span>
                        </Descriptions.Item>
                        <Descriptions.Item label="Email">
                            <Link to={`mailto:${user.email}`}>
                                <MailOutlined /> {user.email}
                            </Link>
                        </Descriptions.Item>
                        <Descriptions.Item label="Téléphone">
                            {user.phone ? <Link to={`tel:${user.phone}`}><PhoneOutlined /> {user.phone}</Link> : "N/A"}
                        </Descriptions.Item>
                        <Descriptions.Item label="Rôle">
                            <Tag color={user.role === "ADMIN" ? "red" : user.role === "INSTITUT" ? "blue" : "green"}>
                                {user.role}
                            </Tag>
                        </Descriptions.Item>
                        <Descriptions.Item label="Statut">
                            <Tag color={user.enabled ? "green" : "red"}>
                                {user.enabled ? "Actif" : "Inactif"}
                            </Tag>
                        </Descriptions.Item>
                        <Descriptions.Item label="Dernière connexion">
                            {user.updatedAt ? new Date(user.updatedAt).toLocaleString() : "Jamais"}
                        </Descriptions.Item>
                        <Descriptions.Item label="Créé le">
                            {new Date(user.createdAt).toLocaleString()}
                        </Descriptions.Item>
                    </Descriptions>
                    <h3 className="text-lg font-semibold mb-4">Permissions</h3>
                    <Space wrap>
                        {user.permissions && user.permissions.length > 0 ? (
                            user.permissions.map((permission) => (
                                <Tag key={permission.id} color={getPermissionColor(permission.key)}>
                                    {getPermissionLabel(permission.key)}
                                </Tag>
                            ))
                        ) : (
                            <Tag color="gray">Aucune permission</Tag>
                        )}
                    </Space>
                    <Divider />
                    {user.organization && (
                        <>
                            <h3 className="text-lg font-semibold mb-4">Organisation</h3>
                            <Descriptions bordered>
                                <Descriptions.Item label="Nom" span={2}>{user.organization.name}</Descriptions.Item>
                                <Descriptions.Item label="Type">{user.organization.type}</Descriptions.Item>
                                
                            </Descriptions>
                        </>
                    )}
                </Card>
            </div>
        </div>
    );
};

export default UserDetail;
