import { useEffect, useState, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Table, Tag, Space, Avatar, Breadcrumb, Button, Input, Select, message, Modal } from "antd";
import { UserOutlined, SearchOutlined } from "@ant-design/icons";
import { PiPlusDuotone } from "react-icons/pi";
import { useAuth } from "../../../hooks/useAuth";
import userService from "../../../services/userService";
import { getPermissionLabel } from "../../../auth/permissions"
import { PERMS } from "../../../auth/permissions";

const { Search } = Input;

const UserList = () => {
    const { user: currentUser } = useAuth();
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [pagination, setPagination] = useState({
        current: 1,
        pageSize: 10,
        total: 0,
    });
    const [filters, setFilters] = useState({
        search: "",
        role: null,
        status: null,
    });
    const [sortConfig, setSortConfig] = useState({
        field: "createdAt",
        order: "descend",
    });
    const navigate = useNavigate();

    const fetchUsers = useCallback(async () => {
        setLoading(true);
        try {
            const params = {
                page: pagination.current,
                limit: pagination.pageSize,
                search: filters.search,
                ...(filters.role && { role: filters.role }),
                ...(filters.status && { status: filters.status }),
                sortBy: sortConfig.field,
                sortOrder: sortConfig.order === "ascend" ? "asc" : "desc",
            };
            const response = await userService.list(params);
            setUsers(
                currentUser?.role === "SUPER_ADMIN"
                    ? response.users
                    : response.users.filter(user => user.role !== "SUPER_ADMIN")
            );
            setPagination(prev => ({
                ...prev,
                total: response.pagination.total,
            }));
        } catch (error) {
            console.error("Erreur lors de la récupération des utilisateurs:", error);
        } finally {
            setLoading(false);
        }
    }, [pagination.current, pagination.pageSize, filters, sortConfig, currentUser]);

    useEffect(() => {
        document.documentElement.setAttribute("dir", "ltr");
        document.documentElement.classList.add("light");
        document.documentElement.classList.remove("dark");
        fetchUsers();
    }, [fetchUsers]);

    const handleTableChange = (newPagination, _, sorter) => {
        if (newPagination.current !== pagination.current || newPagination.pageSize !== pagination.pageSize) {
            setPagination({
                ...pagination,
                current: newPagination.current,
                pageSize: newPagination.pageSize,
            });
        }
        if (sorter && sorter.field) {
            setSortConfig({
                field: sorter.field,
                order: sorter.order,
            });
        }
    };

    const handleSearch = (value) => {
        setFilters(prev => ({ ...prev, search: value }));
        setPagination(prev => ({ ...prev, current: 1 }));
    };

    const handleFilterChange = (field, value) => {
        setFilters(prev => ({ ...prev, [field]: value }));
        setPagination(prev => ({ ...prev, current: 1 }));
    };

    const clearFilters = () => {
        setFilters({
            search: "",
            role: null,
            status: null,
        });
        setPagination(prev => ({ ...prev, current: 1 }));
    };

    const handleDeleteUser = async (userId) => {
        try {
            await userService.archive(userId);
            message.success("Utilisateur archivé avec succès");
            fetchUsers();
        } catch (error) {
            message.error("Échec de l'archivage");
            console.error(error);
        }
    };

    const roleOptions = [
        { value: "ADMIN", label: "Administrateur" },
        { value: "SUPER_ADMIN", label: "Super Administrateur" },
        { value: "SUPERVISEUR", label: "Superviseur" },
        { value: "INSTITUT", label: "Institut" },
        { value: "DEMANDEUR", label: "Demandeur" },
        { value: "TRADUCTEUR", label: "Traducteur" },
    ];

    const permissionsOptions = Object.entries(PERMS).map(([key, value]) => ({
        value: value,
        label: getPermissionLabel(value),
    }));

    const statusOptions = [
        { value: "ACTIVE", label: "Actif" },
        { value: "INACTIVE", label: "Inactif" },
    ];

    const columns = [
        {
            title: "Nom complet",
            dataIndex: ["firstName", "lastName"],
            key: "name",
            sorter: true,
            render: (_, record) => (
                <Space size="middle">
                    <Avatar
                        size="default"
                        icon={<UserOutlined />}
                        src={record.avatar}
                    />
                    <Link to={`/admin/users/${record.id}/details`}>
                        {record.firstName || ""} {record.lastName || ""}
                    </Link>
                </Space>
            ),
        },
        {
            title: "Email",
            dataIndex: "email",
            key: "email",
            sorter: true,
        },
        {
            title: "Téléphone",
            dataIndex: "phone",
            key: "phone",
            render: (phone) => phone || "N/A",
        },
        {
            title: "Rôle",
            dataIndex: "role",
            key: "role",
            filters: roleOptions,
            filterSearch: true,
            onFilter: (value, record) => record.role === value,
            render: (role) => (
                <Tag color={(role === "ADMIN" || role === "SUPER_ADMIN") ? "red" :
                    role === "INSTITUT" ? "blue" :
                        role === "DEMANDEUR" ? "orange" :
                            role === "TRADUCTEUR" ? "cyan" :
                                role === "SUPERVISEUR" ? "purple" : "green"}>

                    {role === "ADMIN" ? "Administrateur" :
                        role === "SUPER_ADMIN" ? "SA" :
                            role === "INSTITUT" ? "Institution" :
                                role === "TRADUCTEUR" ? "Traducteur" :
                                    role === "DEMANDEUR" ? "Demandeur" :
                                    role === "SUPERVISEUR" ? "Superviseur" : "Utilisateur"}
                </Tag>
            ),
        },
        {
            title: "Statut",
            dataIndex: "enabled",
            key: "status",
            filters: statusOptions,
            filterSearch: true,
            onFilter: (value, record) => record.enabled === (value === "ACTIVE"),
            render: (enabled) => (
                <Tag color={enabled ? "green" : "red"}>
                    {enabled ? "Actif" : "Inactif"}
                </Tag>
            ),
        },
        // {
        //     title: "Permissions",
        //     key: "permissions",
        //     render: (_, record) => (
        //         <Space size="small" wrap>
        //             {record.permissions?.map((p) => (
        //                 <Tag key={p.id} color={getPermissionColor(p.key)}>
        //                     {getPermissionLabel(p.key)}
        //                 </Tag>
        //             ))}
        //         </Space>
        //     ),
        // },
        {
            title: "Actions",
            key: "actions",
            render: (_, record) => (
                <Space size="middle">
                    <Button type="link">
                        <Link to={`/admin/users/${record.id}/details`}>Détails</Link>
                    </Button>
                    <Button type="link">
                        <Link to={`/admin/users/${record.id}/edit`}>Modifier</Link>
                    </Button>
                    {currentUser?.role === "SUPER_ADMIN" && record.role !== "SUPER_ADMIN" && (
                        <Button
                            type="link"
                            danger
                            onClick={() => {
                                Modal.confirm({
                                    title: "Archiver cet utilisateur ?",
                                    content: "Cette action est irréversible.",
                                    okText: "Archiver",
                                    okType: "danger",
                                    cancelText: "Annuler",
                                    onOk: () => handleDeleteUser(record.id),
                                });
                            }}
                        >
                            Archiver
                        </Button>
                    )}
                </Space>
            ),
        },
    ];

    return (
        <div className="container-fluid relative px-3">
            <div className="layout-specing">
                <div className="md:flex justify-between items-center mb-6">
                    <h5 className="text-lg font-semibold">Liste des utilisateurs</h5>
                    <Breadcrumb
                        items={[
                            { title: <Link to="/">Dashboard</Link> },
                            { title: "Liste des utilisateurs" },
                        ]}
                    />
                </div>
                <div className="mb-6 bg-white p-4 rounded-lg shadow-sm">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 w-full">
                        <div className="w-full md:flex-1">
                            <Search
                                placeholder="Rechercher un utilisateur..."
                                allowClear
                                enterButton={<SearchOutlined />}
                                size="large"
                                onSearch={handleSearch}
                                className="w-full"
                            />
                        </div>
                        <div className="flex flex-wrap gap-4 w-full md:w-auto justify-start sm:justify-center md:justify-end">
                            <Select
                                placeholder="Filtrer par rôle"
                                allowClear
                                className="w-full sm:w-44"
                                onChange={(value) => handleFilterChange("role", value)}
                                options={roleOptions}
                            />
                            <Select
                                placeholder="Filtrer par statut"
                                allowClear
                                className="w-full sm:w-44"
                                onChange={(value) => handleFilterChange("status", value)}
                                options={statusOptions}
                            />
                            <Select
                                placeholder="Filtrer par permissions"
                                allowClear
                                className="w-full sm:w-44"
                                onChange={(value) => handleFilterChange("permissions", value)}
                                options={permissionsOptions}
                            />
                            <Button className="w-full sm:w-auto" onClick={clearFilters}>
                                Réinitialiser
                            </Button>
                        </div>
                        <div className="w-full md:w-auto flex justify-start md:justify-end">
                            <Button
                                type="primary"
                                onClick={() => navigate("/admin/users/create")}
                                icon={<PiPlusDuotone />}
                                className="w-full sm:w-auto"
                            >
                                Nouvel Utilisateur
                            </Button>
                        </div>
                    </div>
                </div>
                <Table
                    columns={columns}
                    dataSource={users}
                    loading={loading}
                    rowKey="id"
                    pagination={{
                        ...pagination,
                        showSizeChanger: true,
                        pageSizeOptions: ["5", "10", "20", "50"],
                        showTotal: (total) => `Total ${total} utilisateurs`,
                    }}
                    onChange={handleTableChange}
                    scroll={{ x: true }}
                    className="responsive-table"
                />
            </div>
        </div>
    );
};

export default UserList;
