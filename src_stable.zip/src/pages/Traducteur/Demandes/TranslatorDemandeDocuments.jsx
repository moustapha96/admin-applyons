
/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
"use client";

import { useEffect, useState, useCallback } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  Breadcrumb,
  Button,
  Card,
  Descriptions,
  Input,
  Modal,
  Space,
  Table,
  Tag,
  message,
  Tooltip,
  Select,
  Upload,
  Typography,
  Popconfirm,
} from "antd";
import {
  EyeOutlined,
  DownloadOutlined,
  SafetyCertificateOutlined,
  ReloadOutlined,
  CloudUploadOutlined,
  InfoCircleOutlined,
} from "@ant-design/icons";
import documentService from "@/services/documentService";
import demandeService from "@/services/demandeService";

const { Dragger } = Upload;
const { Text } = Typography;

const STATUS_COLORS = {
  PENDING: "blue",
  IN_PROGRESS: "gold",
  VALIDATED: "green",
  REJECTED: "red",
};

const safeUrl = (u) => {
  if (!u) return null;
  if (/^https?:\/\/[^/]+uploads\//i.test(u)) {
    return u.replace(/(https?:\/\/[^/]+)uploads\//i, "$1/uploads/");
  }
  return u;
};

export default function DemandeDocumentsPage() {
  const navigate = useNavigate();
  const { demandeId } = useParams();

  // En-tête demande
  const [demande, setDemande] = useState(null);

  // Table documents
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [pag, setPag] = useState({ current: 1, pageSize: 10, total: 0 });
  const [filters, setFilters] = useState({
    search: "",
    demandePartageId: demandeId,
    ownerOrgId: undefined,
    estTraduit: undefined,
    from: undefined,
    to: undefined,
  });

  // Modal upload traduction
  const [openModal, setOpenModal] = useState(false);
  const [currentDoc, setCurrentDoc] = useState(null);
  const [uploadFile, setUploadFile] = useState(null);
  const [encryptionKeyTraduit, setEncryptionKeyTraduit] = useState("");

  const fetchDemande = useCallback(async () => {
    try {
      const d = await demandeService.getById(demandeId);
      setDemande(d?.demande || d?.data?.demande || null);
    } catch (e) {
      message.error(e?.response?.data?.message || e?.message || "Échec chargement de la demande");
    }
  }, [demandeId]);

  const fetch = useCallback(
    async (page = pag.current, pageSize = pag.pageSize, f = filters) => {
      setLoading(true);
      try {
        const { documents, pagination } = await documentService.list({
          page,
          limit: pageSize,
          search: f.search || undefined,
          demandePartageId: f.demandePartageId || undefined,
          ownerOrgId: f.ownerOrgId || undefined,
          estTraduit: typeof f.estTraduit === "boolean" ? f.estTraduit : undefined,
          from: f.from || undefined,
          to: f.to || undefined,
        });
        console.log(documents)
        setRows(documents || []);
        setPag({ current: page, pageSize, total: pagination?.total || 0 });
      } catch (e) {
        message.error(e?.response?.data?.message || e?.message || "Erreur chargement des documents");
      } finally {
        setLoading(false);
      }
    },
    [pag.current, pag.pageSize, filters]
  );

  useEffect(() => {
    fetchDemande();
    setFilters((prev) => ({ ...prev, demandePartageId: demandeId }));
    fetch(1, pag.pageSize, { ...filters, demandePartageId: demandeId });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [demandeId]);

  // Actions Documents
  const viewDoc = (row, type = "original") => {
    const url =
      type === "traduit"
        ? safeUrl(row.urlTraduit || row.urlChiffreTraduit)
        : safeUrl(row.urlOriginal || row.urlChiffre);
    if (!url) return message.warning("Aucun fichier disponible pour cet affichage.");
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const downloadDoc = (row, type = "original") => {
    const url =
      type === "traduit"
        ? safeUrl(row.urlTraduit || row.urlChiffreTraduit)
        : safeUrl(row.urlOriginal || row.urlChiffre);
    if (!url) return message.warning("Aucun fichier à télécharger.");
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const verify = async (docId) => {
    try {
      const r = await documentService.verifyIntegrity(docId);
      const ok = r?.ok ?? r?.data?.ok ?? true;
      message.success(ok ? "Intégrité vérifiée" : "Problème d’intégrité détecté");
    } catch (e) {
      message.error(e?.response?.data?.message || e?.message || "Échec vérification d’intégrité");
    }
  };

  // Traduction (upload)
  const openUploadTranslation = (doc) => {
    setCurrentDoc(doc);
    setUploadFile(null);
    setEncryptionKeyTraduit("");
    setOpenModal(true);
  };

  const onChangeUpload = ({ fileList }) => {
    setUploadFile(fileList?.[0]?.originFileObj || null);
  };

  const submitUploadTranslation = async () => {
    if (!currentDoc) return;
    if (!uploadFile) {
      message.warning("Sélectionne un PDF traduit.");
      return;
    }
    try {
      const form = new FormData();
      form.append("file", uploadFile);
      if (encryptionKeyTraduit) form.append("encryptionKeyTraduit", encryptionKeyTraduit);

      await documentService.traduireUpload(currentDoc.id, form);
      message.success("Traduction uploadée (chiffrement en place)");
      setOpenModal(false);
      fetch(pag.current, pag.pageSize, filters);
    } catch (e) {
      message.error(e?.response?.data?.message || e?.message || "Échec upload de la traduction");
    }
  };

  // Suppression de la traduction
  const deleteTranslation = async (docId) => {
    try {
      await documentService.deleteTranslated(docId);
      message.success("Traduction supprimée");
      fetch(pag.current, pag.pageSize, filters);
    } catch (e) {
      message.error(e?.response?.data?.message || e?.message || "Échec suppression");
    }
  };

  const TagBool = ({ truthy, labelTrue, labelFalse }) => (
    <Tag color={truthy ? "geekblue" : "default"}>{truthy ? labelTrue : labelFalse}</Tag>
  );

  const short = (s) => (s ? String(s).slice(0, 8) + "…" : "—");
  const formatDT = (v) => (v ? new Date(v).toLocaleString() : "—");

  const columns = [
    {
      title: "Institut (source)",
      key: "ownerOrg",
      render: (_, r) =>
        r.ownerOrg ? (
          <Space direction="vertical" size={0}>
            <span className="font-medium">{r.ownerOrg.name}</span>
            <Tag>{r.ownerOrg.slug}</Tag>
          </Space>
        ) : (
          <Tag>—</Tag>
        ),
      width: 220,
    },
    {
      title: "Demande",
      key: "demandePartage",
      render: (_, r) =>
        r.demandePartage ? (
          <Space direction="vertical" size={0}>
            <span>{r.demandePartage.code}</span>
            <Tag>{r.demandePartage.status || "—"}</Tag>
          </Space>
        ) : (
          "—"
        ),
      width: 180,
    },
    {
      title: "Type",
      dataIndex: "type",
      key: "type",
      width: 160,
      render: (v, r) => v || (r.estTraduit ? "TRADUCTION" : "ORIGINAL"),
    },
    {
      title: "Original",
      key: "original",
      render: (_, r) => (
        <Space direction="vertical">
          <Space>
            <Button size="small" icon={<EyeOutlined />} onClick={() => viewDoc(r, "original")}>
              Voir
            </Button>  
          </Space>
         
        </Space>
      ),
      width: 360,
    },
    {
      title: "Traduit",
      key: "traduit",
      render: (_, r) =>
        r.urlTraduit ? (
          <Space direction="vertical">
            <Space>
              <Tag color="green">Disponible</Tag>
              <Button size="small" icon={<EyeOutlined />} onClick={() => viewDoc(r, "traduit")}>
                Voir
              </Button>
             
              <Tooltip title="Supprimer la traduction">
                <Popconfirm
                  title="Supprimer la traduction ?"
                  description="Cette action retirera le fichier traduit et les métadonnées associées."
                  okText="Supprimer"
                  okButtonProps={{ danger: true }}
                  cancelText="Annuler"
                  onConfirm={() => deleteTranslation(r.id)}
                >
                  <Button size="small" danger>
                    Supprimer
                  </Button>
                </Popconfirm>
              </Tooltip>
            </Space>
           
          </Space>
        ) : (
          <Space direction="vertical">
            <Tag>N/A</Tag>
            <Tooltip title="Uploader le PDF traduit">
              <Button type="primary" icon={<CloudUploadOutlined />} onClick={() => openUploadTranslation(r)}>
                Traduire
              </Button>
            </Tooltip>
            <Text type="secondary" style={{ fontSize: 12 }}>
              Le PDF traduit sera chiffré et rattaché à ce document.
            </Text>
          </Space>
        ),
      width: 420,
    },
  ];

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <h5 className="text-lg font-semibold">Documents de la demande</h5>
          <Breadcrumb
            items={[
              { title: <Link to="/">Dashboard</Link> },
              { title: <Link to="/traducteur/demandes">Demandes</Link> },
              { title: "Documents" },
            ]}
          />
        </div>

        <Space className="mb-4" wrap>
          <Button onClick={() => navigate(-1)}>Retour</Button>
          <Button icon={<ReloadOutlined />} onClick={() => fetch(pag.current, pag.pageSize, filters)}>
            Rafraîchir
          </Button>
        </Space>

        {demande && (
          <Card className="mb-4" title="Informations demande">
            <Descriptions bordered column={3}>
              <Descriptions.Item label="Code">{demande.code || "—"}</Descriptions.Item>
              <Descriptions.Item label="Statut de la demande">
                <Tag color={STATUS_COLORS[demande.status || "PENDING"] || "blue"}>
                  {demande.status || "PENDING"}
                </Tag>
              </Descriptions.Item>
              <Descriptions.Item label="Demandeur">
                {demande.user?.id ? (
                  <Link to={`/traducteur/demandeur/${demande.user.id}/details`}>
                    {demande.user?.email || demande.user?.username || "—"}
                  </Link>
                ) : (
                  demande.user?.email || demande.user?.username || "—"
                )}
              </Descriptions.Item>
              <Descriptions.Item label="Institut cible" span={3}>
                {demande.targetOrg?.name || "—"}
              </Descriptions.Item>
            </Descriptions>
          </Card>
        )}

        <Card
          title="Documents"
          extra={
            <Space wrap>
              <Input.Search
                allowClear
                placeholder="Recherche…"
                onSearch={(v) => {
                  const next = { ...filters, search: v };
                  setFilters(next);
                  fetch(1, pag.pageSize, next);
                }}
                style={{ width: 260 }}
              />
              <Select
                allowClear
                placeholder="Traduit ?"
                style={{ width: 160 }}
                value={filters.estTraduit}
                onChange={(v) => {
                  const next = { ...filters, estTraduit: v };
                  setFilters(next);
                  fetch(1, pag.pageSize, next);
                }}
                options={[
                  { value: true, label: "Oui" },
                  { value: false, label: "Non" },
                ]}
              />
            </Space>
          }
        >
          <Table
            rowKey="id"
            loading={loading}
            columns={columns}
            dataSource={rows}
            pagination={{
              current: pag.current,
              pageSize: pag.pageSize,
              total: pag.total,
              showSizeChanger: true,
              pageSizeOptions: ["5", "10", "20", "50", "100"],
              onChange: (p, ps) => fetch(p, ps, filters),
              showTotal: (t) => `${t} document(s)`,
            }}
            scroll={{ x: true }}
          />
        </Card>
      </div>

      {/* Modal Upload Traduction */}
      <Modal
        open={openModal}
        title={currentDoc ? `Uploader la traduction — Doc ${currentDoc.id}` : "Uploader une traduction"}
        onCancel={() => setOpenModal(false)}
        onOk={submitUploadTranslation}
        okText="Enregistrer"
        destroyOnHidden
      >
        <Space direction="vertical" style={{ width: "100%" }}>
          <Dragger
            multiple={false}
            accept=".pdf"
            beforeUpload={() => false}
            onChange={onChangeUpload}
            fileList={uploadFile ? [{ uid: "1", name: uploadFile.name }] : []}
          >
            <p className="ant-upload-drag-icon">
              <CloudUploadOutlined />
            </p>
            <p className="ant-upload-text">Glissez le PDF traduit ici ou cliquez pour sélectionner</p>
            <p className="ant-upload-hint">Taille max. 5 Mo — PDF uniquement</p>
          </Dragger>

        </Space>
      </Modal>
    </div>
  );
}
