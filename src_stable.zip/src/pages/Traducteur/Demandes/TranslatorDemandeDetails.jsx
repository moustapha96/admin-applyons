
/* eslint-disable no-unused-vars */
"use client";

import { useEffect, useMemo, useState, useCallback } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import {
  Card,
  Row,
  Col,
  Descriptions,
  Tag,
  Space,
  Button,
  Typography,
  message,
  Breadcrumb,
  Modal,
  Upload,
  Input,
  Tooltip,
  Popconfirm,
  Spin,
} from "antd";
import dayjs from "dayjs";
import demandeService from "@/services/demandeService";
import documentService from "@/services/documentService";
import { CloudUploadOutlined, EyeOutlined, DownloadOutlined } from "@ant-design/icons";

const { Title, Text } = Typography;
const { Dragger } = Upload;

const fmtDate = (d, f = "DD/MM/YYYY") => (d ? (dayjs(d).isValid() ? dayjs(d).format(f) : "—") : "—");
const yesNo = (v) => (v ? "Oui" : "Non");

const statusColor = (status) => {
  switch ((status || "PENDING").toUpperCase()) {
    case "VALIDATED":
      return "green";
    case "REJECTED":
      return "red";
    case "IN_PROGRESS":
      return "gold";
    case "PENDING":
    default:
      return "blue";
  }
};

// Corrige les URLs sans slash après le host (ex: http://localhost:5000uploads/...)
const safeUrl = (u) => {
  if (!u) return null;
  if (/^https?:\/\/[^/]+uploads\//i.test(u)) {
    return u.replace(/(https?:\/\/[^/]+)uploads\//i, "$1/uploads/");
  }
  return u;
};

export default function TranslatorDemandeDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [demande, setDemande] = useState(null);
  const [documents, setDocuments] = useState([]);

  // Modal upload traduction
  const [openModal, setOpenModal] = useState(false);
  const [currentDoc, setCurrentDoc] = useState(null);
  const [uploadFile, setUploadFile] = useState(null);
  const [encryptionKeyTraduit, setEncryptionKeyTraduit] = useState("");
  const [uploading, setUploading] = useState(false);


  // Modal preview PDF
  const [preview, setPreview] = useState({ open: false, url: "", title: "" });

  const fetchDemande = useCallback(async () => {
    setLoading(true);
    try {
      const res = await demandeService.getById(id);
      const d = res?.demande ?? res ?? null;
      if (!d) {
        message.warning("Aucune donnée de demande.");
        setDemande(null);
        setDocuments([]);
        return;
      }
      setDemande(d);
      setDocuments(Array.isArray(d.documents) ? d.documents : []);
    } catch (e) {
      message.error(e?.response?.data?.message || e?.message || "Échec chargement");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchDemande();
  }, [fetchDemande]);

  const updateStatus = async (status) => {
    try {
      await demandeService.changeStatus(id, status);
      message.success("Statut mis à jour");
      fetchDemande();
    } catch (e) {
      message.error(e?.response?.data?.message || e?.message || "Échec MAJ statut");
    }
  };

  const docsCount = useMemo(() => {
    return (
      (demande?._count && typeof demande._count.documents === "number" && demande._count.documents) ||
      documents.length ||
      0
    );
  }, [demande, documents]);

  // Upload traduction
  const openUploadTranslation = (doc) => {
    setCurrentDoc(doc);
    setUploadFile(null);
    setEncryptionKeyTraduit("");
    setOpenModal(true);
  };
  const onChangeUpload = ({ fileList }) => {
    setUploadFile(fileList?.[0]?.originFileObj || null);
  };
  const submitUploadTranslation = async () => {
    if (!currentDoc) return;
    if (!uploadFile) {
      return message.warning("Sélectionne un PDF traduit.");
    }
    setUploading(true);
    try {
      const form = new FormData();
      form.append("file", uploadFile);
      await documentService.traduireUpload(currentDoc.id, form);
      message.success("Traduction uploadée (chiffrement en place)");
      setOpenModal(false);
      await fetchDemande();
    } catch (e) {
      message.error(e?.response?.data?.message || e?.message || "Échec upload de la traduction");
    } finally {
      setUploading(false); // Désactive le loader
    }
  };

  // Suppression traduction
  const deleteTranslation = async (docId) => {
    try {
      await documentService.deleteTranslation(docId);
      message.success("Traduction supprimée");
      await fetchDemande();
    } catch (e) {
      message.error(e?.response?.data?.message || e?.message || "Échec suppression");
    }
  };

  // Prévisualisation intégrée (in-app)
  const openPreview = (doc, kind = "original") => {
    const raw =
      kind === "traduit"
        ? (safeUrl(doc.urlTraduit) || safeUrl(doc.urlChiffreTraduit))
        : (safeUrl(doc.urlOriginal) || safeUrl(doc.urlChiffre));

    if (!raw) {
      message.warning("Aucun fichier disponible à afficher.");
      return;
    }
    // Option : si tu as un endpoint sécurisé de content streaming, utilise-le ici
    // const url = documentService.getDocumentContentUrl(doc.id, kind, true);
    const url = raw;
    setPreview({
      open: true,
      url,
      title: `${kind === "traduit" ? "PDF traduit" : "PDF original"} — ${doc.id}`,
    });
  };

  const downloadDirect = (doc, kind = "original") => {
    const raw =
      kind === "traduit"
        ? (safeUrl(doc.urlTraduit) || safeUrl(doc.urlChiffreTraduit))
        : (safeUrl(doc.urlOriginal) || safeUrl(doc.urlChiffre));
    if (!raw) {
      message.warning("Aucun fichier à télécharger.");
      return;
    }
    window.open(raw, "_blank", "noopener,noreferrer");
  };

  return (
    <>
      <div className="container-fluid relative px-3">
        <div className="layout-specing">
          <div className="md:flex justify-between items-center mb-6">
            <h5 className="text-lg font-semibold">Demandes à traiter</h5>
            <Breadcrumb
              items={[
                { title: <Link to="/traducteur/dashboard">Tableau de bord</Link> },
                { title: <Link to="/traducteur/demandes">Demandes à traiter</Link> },
                { title: "Demandes" },
              ]}
            />
          </div>

          <div className="p-2 md:p-4">
            <Space align="center" className="mb-2" size="middle" wrap>
              <Title level={3} style={{ margin: 0 }}>
                Détails de la demande
              </Title>
              <Button onClick={() => navigate(-1)}>Retour</Button>
              <Link to={`/traducteur/demandes/${id}/documents`}>
                <Button type="primary">Documents & Traductions</Button>
              </Link>
            </Space>

            <Row gutter={[16, 16]}>
              <Col xs={24} md={14}>
                <Card loading={loading} title="Informations générales">
                  {demande && (
                    <Descriptions bordered column={1} size="small">
                      <Descriptions.Item label="Code">{demande.code || "—"}</Descriptions.Item>
                      <Descriptions.Item label="Date de demande">{fmtDate(demande.dateDemande)}</Descriptions.Item>
                      <Descriptions.Item label="Statut">
                        <Tag color={statusColor(demande.status)}>{demande.status || "PENDING"}</Tag>
                      </Descriptions.Item>
                      <Descriptions.Item label="Demandeur">
                        {demande.user?.firstName || demande.user?.lastName
                          ? `${demande.user?.firstName || ""} ${demande.user?.lastName || ""}`.trim()
                          : demande.user?.email || "—"}
                      </Descriptions.Item>
                      <Descriptions.Item label="Institut cible">
                        {demande.targetOrg?.name || "—"}{" "}
                        {demande.targetOrg?.type && <Tag style={{ marginLeft: 8 }}>{demande.targetOrg?.type}</Tag>}
                      </Descriptions.Item>
                      <Descriptions.Item label="Organisation assignée">
                        {demande.assignedOrg?.name || "—"}{" "}
                        {demande.assignedOrg?.type && <Tag style={{ marginLeft: 8 }}>{demande.assignedOrg?.type}</Tag>}
                      </Descriptions.Item>
                      <Descriptions.Item label="Période / Année">
                        {demande.periode || "—"} / {demande.year || "—"}
                      </Descriptions.Item>
                      <Descriptions.Item label="Série / Niveau / Mention">
                        {(demande.serie || "—") + " / " + (demande.niveau || "—") + " / " + (demande.mention || "—")}
                      </Descriptions.Item>
                      <Descriptions.Item label="Établissement secondaire">
                        {(demande.secondarySchoolName || "—") + " (" + (demande.countryOfSchool || "—") + ")"}
                      </Descriptions.Item>
                      <Descriptions.Item label="Date obtention diplôme">{fmtDate(demande.graduationDate)}</Descriptions.Item>
                      <Descriptions.Item label="Date de naissance">{fmtDate(demande.dob)}</Descriptions.Item>
                      <Descriptions.Item label="Nationalité / Passeport">
                        {(demande.citizenship || "—") + " / " + (demande.passport || "—")}
                      </Descriptions.Item>
                      <Descriptions.Item label="Anglais langue maternelle">{yesNo(demande.isEnglishFirstLanguage)}</Descriptions.Item>
                      <Descriptions.Item label="Tests d'anglais">{demande.englishProficiencyTests || "—"}</Descriptions.Item>
                      <Descriptions.Item label="Scores / GPA / Échelle">
                        {(demande.testScores || "—") + " / " + (demande.gpa || "—") + " / " + (demande.gradingScale || "—")}
                      </Descriptions.Item>
                      <Descriptions.Item label="Examens passés">{demande.examsTaken || "—"}</Descriptions.Item>
                      <Descriptions.Item label="Filière visée">{demande.intendedMajor || "—"}</Descriptions.Item>
                      <Descriptions.Item label="Activités & Distinctions">
                        {(demande.extracurricularActivities || "—") + " / " + (demande.honorsOrAwards || "—")}
                      </Descriptions.Item>
                      <Descriptions.Item label="Parent / Tuteur (Niveau/Profession)">
                        {(demande.parentGuardianName || "—") +
                          " / " +
                          (demande.educationLevel || "—") +
                          " / " +
                          (demande.occupation || "—")}
                      </Descriptions.Item>
                      <Descriptions.Item label="Aide financière / Sponsoring">
                        {yesNo(demande.willApplyForFinancialAid)} / {yesNo(demande.hasExternalSponsorship)}
                      </Descriptions.Item>
                      <Descriptions.Item label="Visa / Études prév. aux USA">
                        {(demande.visaType || "—") + " / " + yesNo(demande.hasPreviouslyStudiedInUS)}
                      </Descriptions.Item>
                      <Descriptions.Item label="Personal Statement">
                        <Text>{demande.personalStatement || "—"}</Text>
                      </Descriptions.Item>
                      <Descriptions.Item label="Essai optionnel">
                        <Text>{demande.optionalEssay || "—"}</Text>
                      </Descriptions.Item>
                      <Descriptions.Item label="Tour d'application / Découverte">
                        {(demande.applicationRound || "—") + " / " + (demande.howDidYouHearAboutUs || "—")}
                      </Descriptions.Item>
                      <Descriptions.Item label="Observation">
                        <Text>{demande.observation || "—"}</Text>
                      </Descriptions.Item>
                      <Descriptions.Item label="Créé / Mis à jour">
                        {fmtDate(demande.createdAt, "DD/MM/YYYY HH:mm")} / {fmtDate(demande.updatedAt, "DD/MM/YYYY HH:mm")}
                      </Descriptions.Item>
                      <Descriptions.Item label="Documents">
                        <Tag>{docsCount}</Tag>
                      </Descriptions.Item>
                    </Descriptions>
                  )}
                </Card>

              </Col>

              <Col xs={24} md={10}>
                <Card loading={loading} title="Documents (aperçu)">
                  <Space direction="vertical" style={{ width: "100%" }}>
                    {documents.slice(0, 5).map((d) => {
                      const uOrig = safeUrl(d.urlOriginal) || safeUrl(d.urlChiffre);
                      const uTrad = safeUrl(d.urlTraduit) || safeUrl(d.urlChiffreTraduit);
                      return (
                        <div
                          key={d.id}
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            gap: 12,
                            width: "100%",
                          }}
                        >
                          <div style={{ minWidth: 0 }}>
                            <div>
                              <Tag style={{ marginTop: 4 }}>{d.ownerOrg?.name || "—"}</Tag>
                              {d.estTraduit ? <Tag color="green">Traduit</Tag> : <Tag>Non traduit</Tag>}
                            </div>
                          </div>

                          <Space wrap size="small">


                            {uOrig && (
                              <a href={uOrig} target="_blank" rel="noreferrer">
                                <Button
                                  size="small"
                                  icon={<EyeOutlined />}
                                  type="default"
                                  onClick={() => openPreview(d, "traduit")}
                                >
                                  Voir
                                </Button>
                              </a>
                            )}

                            {uTrad && (
                              <>
                                <a href={uTrad} target="_blank" rel="noreferrer">
                                  <Button
                                    size="small"
                                    icon={<EyeOutlined />}
                                    type="default"
                                    onClick={() => openPreview(d, "traduit")}
                                  >
                                    Voir (traduit)
                                  </Button>
                                </a>
                              </>
                            )}

                            {/* Uploader traduction si non traduit */}
                            {!d.estTraduit && (
                              <Tooltip title="Uploader le PDF traduit">
                                <Button
                                  size="small"
                                  type="primary"
                                  icon={<CloudUploadOutlined />}
                                  onClick={() => openUploadTranslation(d)}
                                >
                                  Traduire
                                </Button>
                              </Tooltip>
                            )}

                            {/* Supprimer traduction si disponible */}
                            {d.estTraduit && (
                              <Tooltip title="Supprimer la traduction">
                                <Popconfirm
                                  title="Supprimer la traduction ?"
                                  okText="Supprimer"
                                  okButtonProps={{ danger: true }}
                                  cancelText="Annuler"
                                  onConfirm={() => deleteTranslation(d.id)}
                                >
                                  <Button size="small" danger>
                                    Supprimer
                                  </Button>
                                </Popconfirm>
                              </Tooltip>
                            )}


                          </Space>
                        </div>
                      );
                    })}
                    {documents.length === 0 && <Text type="secondary">Aucun document</Text>}
                  </Space>
                </Card>
              </Col>
            </Row>
          </div>
        </div>
      </div>

      {/* Modal Upload Traduction */}
      <Modal
        open={openModal}
        title={currentDoc ? `Uploader la traduction — Doc ${currentDoc.id}` : "Uploader une traduction"}
        onCancel={() => setOpenModal(false)}
        onOk={submitUploadTranslation}
        okText="Enregistrer"
        okButtonProps={{ loading: uploading }}
        destroyOnHidden
      >
        <Spin spinning={uploading}>
          <Space direction="vertical" style={{ width: "100%" }}>
            <Dragger
              multiple={false}
              accept=".pdf"
              beforeUpload={() => false}
              onChange={({ fileList }) => onChangeUpload({ fileList })}
              fileList={uploadFile ? [{ uid: "1", name: uploadFile.name }] : []}
            >
              <p className="ant-upload-drag-icon">
                <CloudUploadOutlined />
              </p>
              <p className="ant-upload-text">Glissez le PDF traduit ici ou cliquez pour sélectionner</p>
              <p className="ant-upload-hint">Taille max. 5 Mo — PDF uniquement</p>
            </Dragger>
          </Space>
        </Spin>


      </Modal>

      {/* Modal Preview PDF */}
      <Modal
        open={preview.open}
        title={preview.title || "Aperçu du document"}
        onCancel={() => setPreview({ open: false, url: "", title: "" })}
        footer={
          <Space>
            {preview.url && (
              <a href={preview.url} target="_blank" rel="noreferrer">
                <Button type="default">Ouvrir dans un nouvel onglet</Button>
              </a>
            )}
            <Button type="primary" onClick={() => setPreview({ open: false, url: "", title: "" })}>
              Fermer
            </Button>
          </Space>
        }
        width="80vw"
        style={{ height: "85vh", padding: 0 }}
        destroyOnHidden
      >
        {preview.url ? (
          <iframe
            src={preview.url}
            title="aperçu-pdf"
            style={{ width: "100%", height: "100%", border: "none" }}
          />
        ) : (
          <div style={{ padding: 16 }}>
            <Text type="secondary">Aucun contenu à afficher.</Text>
          </div>
        )}
      </Modal>
    </>
  );
}
