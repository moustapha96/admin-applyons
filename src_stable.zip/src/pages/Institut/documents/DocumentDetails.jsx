import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Descriptions, Space, Button, message } from "antd";
import http from "@/services/http";

export default function DocumentDetails() {
  const { id } = useParams();
  const [doc, setDoc] = useState();
  const [loading, setLoading] = useState(false);

  const fetchOne = async () => {
    setLoading(true);
    try {
      const { data } = await http.get(`/documents/${id}`);
      setDoc(data?.document || data);
    } finally { setLoading(false); }
  };

  useEffect(()=>{ fetchOne(); },[id]);

  const open = async (type) => {
    try {
      const { data } = await http.get(`/documents/${id}/content`, {
        params: { type, display: true },
      });
      window.open(data?.url || data, "_blank");
    } catch {
      message.error("Impossible d'ouvrir le contenu");
    }
  };

  if (!doc) return null;

  return (
    <div>
      <h2>Document #{id}</h2>
      <Descriptions bordered column={1} loading={loading}>
        <Descriptions.Item label="Demande">{doc.demandePartageId}</Descriptions.Item>
        <Descriptions.Item label="Owner Org">{doc.ownerOrgId}</Descriptions.Item>
        <Descriptions.Item label="Traduit">{doc.estTraduit ? "Oui" : "Non"}</Descriptions.Item>
        <Descriptions.Item label="Chiffré">{doc.isEncrypted ? "Oui" : "Non"}</Descriptions.Item>
       
      </Descriptions>

      <Space style={{ marginTop: 16 }}>
        <Button onClick={()=>open("original")}>Voir original</Button>
        <Button onClick={()=>open("traduit")}>Voir traduit</Button>
        <Button onClick={()=>open("chiffre")}>Voir chiffré</Button>
        <Link to="/documents"><Button>Retour</Button></Link>
      </Space>
    </div>
  );
}
