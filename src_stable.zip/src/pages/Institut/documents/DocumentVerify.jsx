import { useState } from "react";
import { Input, Button, Alert } from "antd";
import http from "@/services/http";

export default function DocumentVerify() {
  const [id, setId] = useState("");
  const [result, setResult] = useState();
  const [loading, setLoading] = useState(false);

  const verify = async () => {
    setLoading(true);
    try {
      const { data } = await http.get(`/documents/${id}/verify`);
      setResult(data);
    } finally { setLoading(false); }
  };

  return (
    <div>
      <h2>Vérifier l’intégrité d’un document</h2>
      <Input placeholder="Document ID" value={id} onChange={e=>setId(e.target.value)} style={{ maxWidth: 320 }} />
      <Button onClick={verify} disabled={!id} loading={loading} style={{ marginLeft: 8 }}>Vérifier</Button>
      {result && (
        <div style={{ marginTop: 16 }}>
          <Alert type={result?.ok ? "success" : "error"} message={result?.message || (result?.ok ? "OK" : "KO")} />
        </div>
      )}
    </div>
  );
}
