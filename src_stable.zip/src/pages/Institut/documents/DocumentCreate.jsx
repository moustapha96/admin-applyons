/* eslint-disable no-unused-vars */
"use client";

import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Card, Typography, Breadcrumb, Button } from "antd";
import DemandeAddDocumentModal from "../../../components/DemandeAddDocumentModal";

const { Title } = Typography;

export default function DemandeDocumentCreate() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const demandeId = searchParams.get("demandeId") || null;

  const [open, setOpen] = useState(true);

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <h5 className="text-lg font-semibold">Nouveau document</h5>
          <Breadcrumb
            items={[
              { title: <Link to="/organisations/dashboard">Dashboard</Link> },
              { title: <Link to="/organisations/demandes">Demandes</Link> },
              { title: "Ajouter un document" },
            ]}
          />
        </div>

        <div className="p-2 md:p-4">
          <Card>
            <Title level={3} className="!mb-2">
              {demandeId ? "Ajouter un document à la demande" : "Ajouter un document (rattachement par code de demande)"}
            </Title>
            <p className="text-gray-500">
              Renseigne le type, la mention, la date d’obtention et dépose le fichier. Si tu n’es pas sur la fiche d’une
              demande, saisis le <strong>code de la demande</strong> pour le rattachement.
            </p>
            <div className="mt-4" />
            <Button onClick={() => navigate(-1)}>Retour</Button>
          </Card>
        </div>
      </div>

      <DemandeAddDocumentModal
        open={open}
        onClose={() => {
          setOpen(false);
          navigate(-1);
        }}
        demandeId={demandeId || undefined}
        onSuccess={() => {
          setOpen(false);
          if (demandeId) navigate(`/organisations/demandes/${demandeId}`);
          else navigate("/organisations/demandes");
        }}
      />
    </div>
  );
}
