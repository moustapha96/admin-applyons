import { Form, Input, Switch, Button, Card, Space, Upload, message } from "antd";
import { InboxOutlined } from "@ant-design/icons";
import { useNavigate, useSearchParams } from "react-router-dom";
import { httpPost } from "../../utils/http";

export default function DocumentUpload(){
  const [form] = Form.useForm();
  const [sp] = useSearchParams();
  const nav = useNavigate();

  const initialValues = {
    demandePartageId: sp.get("demandeId") || "",
    ownerOrgId: "",
    codeAdn: "",
    urlOriginal: "",
    estTraduit: false
  };

  const customRequest = async ({ file, onSuccess, onError })=>{
    try{
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method:"POST", body: fd, credentials:"include" });
      const data = await res.json();
      if(!res.ok) throw new Error(data?.message || "Upload échoué");
      form.setFieldValue("urlOriginal", data.url);
      message.success("Fichier uploadé");
      onSuccess(data);
    }catch(e){
      onError(e);
    }
  };

  const submit = async (values)=>{
    const res = await httpPost("/api/documents", values);
    message.success("Document enregistré");
    nav(`/documents/${res?.document?.id}`);
  };

  return (
    <Card title="Joindre un document">
      <Form form={form} layout="vertical" onFinish={submit} initialValues={initialValues}>
        <Form.Item name="demandePartageId" label="Demande ID" rules={[{ required:true }]}><Input /></Form.Item>
        <Form.Item name="ownerOrgId" label="Organisation propriétaire" rules={[{ required:true }]}><Input /></Form.Item>

        <Form.Item label="Fichier">
          <Upload.Dragger name="file" customRequest={customRequest} multiple={false} accept=".pdf,.png,.jpg,.jpeg">
            <p className="ant-upload-drag-icon"><InboxOutlined /></p>
            <p className="ant-upload-text">Glissez ou cliquez pour téléverser</p>
            <p className="ant-upload-hint">PDF / images</p>
          </Upload.Dragger>
        </Form.Item>

        <Form.Item name="urlOriginal" label="URL du fichier original">
          <Input placeholder="ou colle une URL si déjà hébergé" />
        </Form.Item>

        <Form.Item name="codeAdn" label="Code ADN"><Input /></Form.Item>
        <Form.Item name="estTraduit" label="Déjà traduit" valuePropName="checked"><Switch /></Form.Item>

        <Space>
          <Button type="primary" htmlType="submit">Enregistrer</Button>
          <Button onClick={()=>nav(-1)}>Annuler</Button>
        </Space>
      </Form>
    </Card>
  );
}
