/* eslint-disable no-unused-vars */
"use client";

import { useEffect, useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Card, Table, Tag, Space, Button, Input, DatePicker, Select, Typography, message, Breadcrumb } from "antd";
import dayjs from "dayjs";
import demandeService from "@/services/demandeService";
import { useAuth } from "../../../hooks/useAuth";
import { PlusOutlined, FileAddOutlined, EyeOutlined, ReloadOutlined, SearchOutlined } from "@ant-design/icons";

const { Title, Text } = Typography;
const { RangePicker } = DatePicker;

export default function DossierATraiterTraducteur() {
  const navigate = useNavigate();
  const { user } = useAuth(); // doit exposer organization.id
  const orgId = user?.organization?.id;

  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [pagination, setPagination] = useState({ page: 1, limit: 10, total: 0 });

  const [filters, setFilters] = useState({
    search: "",
    status: undefined,
    from: undefined,
    to: undefined,
    sortBy: "dateDemande",
    sortOrder: "desc",
  });

  const fetchData = async (page = pagination.page, limit = pagination.limit) => {
    if (!orgId) return;
    setLoading(true);
    try {
      const params = {
        page,
        limit,
        sortBy: filters.sortBy,
        sortOrder: filters.sortOrder,
        search: filters.search || undefined,
        status: filters.status || undefined,
        from: filters.from || undefined,
        to: filters.to || undefined,
        targetOrgId: orgId,
      };
      const res = await demandeService.listATraiter(orgId, params);
      console.log(res);
      setRows(res?.demandes || []);
      setPagination({
        page: res?.pagination?.page ?? page,
        limit: res?.pagination?.limit ?? limit,
        total: res?.pagination?.total ?? 0,
      });
    } catch (e) {
      message.error(e?.message || "Échec chargement des demandes");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData(1, pagination.limit);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orgId]);

  const columns = useMemo(
    () => [
      {
        title: "Code",
        dataIndex: "code",
        render: (v, r) => <Link to={`/organisations/demandes/${r.id}`}>{v || "—"}</Link>,
        width: 160,
      },
      { title: "Date", dataIndex: "dateDemande", render: (v) => (v ? dayjs(v).format("DD/MM/YYYY") : "—"), width: 140 },
      { title: "Demandeur", key: "user", render: (_, r) => r.user?.email || r.user?.username || "—" },
      { title: "Assignée à", key: "assigned", render: (_, r) => r.assignedOrg?.name || "—" },
      { title: "Docs", dataIndex: "documentsCount", width: 90 },
      {
        title: "Statut",
        dataIndex: "status",
        render: (s) => <Tag color={s === "VALIDATED" ? "green" : s === "REJECTED" ? "red" : s === "IN_PROGRESS" ? "blue" : "default"}>{s || "PENDING"}</Tag>,
        width: 140,
      },
      {
        title: "Actions",
        key: "actions",
        fixed: "right",
        width: 220,
        render: (_, r) => (
          <Space>
            <Button size="small" icon={<EyeOutlined />} onClick={() => navigate(`/organisations/demandes/${r.id}/details`)}>
              Détails
            </Button>
            <Button
              size="small"
              type="primary"
              icon={<FileAddOutlined />}
              onClick={() => navigate(`/organisations/demandes/${r.id}/documents/add`)}
            >
              Ajouter doc
            </Button>
          </Space>
        ),
      },
    ],
    [navigate]
  );

  return (
    <div className="container-fluid relative px-3">
      <div className="layout-specing">
        <div className="md:flex justify-between items-center mb-6">
          <h5 className="text-lg font-semibold">Nos Demandes à traiter</h5>
          <Breadcrumb
            items={[
              { title: <Link to="/organisations/dashboard">Tableau de bord</Link> },
              { title: "Demandes à traiter" },
            ]}
          />
        </div>

        <div className="p-2 md:p-4">
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <Title level={3} className="!mb-0">
              Demandes à traiter
            </Title>
          </div>

          <Card className="mt-3" title="Filtres">
            <Space wrap>
              <Input
                placeholder="Recherche (code, année, niveau, email…)"
                value={filters.search}
                allowClear
                prefix={<SearchOutlined />}
                onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
                style={{ minWidth: 280 }}
              />
              <Select
                allowClear
                placeholder="Statut"
                value={filters.status}
                onChange={(v) => setFilters((f) => ({ ...f, status: v }))}
                style={{ width: 200 }}
                options={["PENDING", "VALIDATED", "REJECTED", "IN_PROGRESS"].map((s) => ({ label: s, value: s }))}
              />
              <RangePicker
                onChange={(v) =>
                  setFilters((f) => ({
                    ...f,
                    from: v?.[0]?.startOf("day")?.toISOString(),
                    to: v?.[1]?.endOf("day")?.toISOString(),
                  }))
                }
              />
              <Select
                value={filters.sortBy}
                onChange={(v) => setFilters((f) => ({ ...f, sortBy: v }))}
                style={{ width: 200 }}
                options={[
                  { value: "dateDemande", label: "Date demande" },
                  { value: "createdAt", label: "Créé le" },
                  { value: "updatedAt", label: "MAJ le" },
                  { value: "code", label: "Code" },
                ]}
              />
              <Select
                value={filters.sortOrder}
                onChange={(v) => setFilters((f) => ({ ...f, sortOrder: v }))}
                style={{ width: 140 }}
                options={[
                  { value: "asc", label: "ASC" },
                  { value: "desc", label: "DESC" },
                ]}
              />
              <Button type="primary" onClick={() => fetchData(1, pagination.limit)}>
                Appliquer
              </Button>
              <Button
                icon={<ReloadOutlined />}
                onClick={() => {
                  setFilters({ search: "", status: undefined, from: undefined, to: undefined, sortBy: "dateDemande", sortOrder: "desc" });
                  fetchData(1, pagination.limit);
                }}
              >
                Réinitialiser
              </Button>
            </Space>
          </Card>

          <Card className="mt-3" title="Liste des demandes">
            <Table
              rowKey={(r) => r.id}
              loading={loading}
              columns={columns}
              dataSource={rows}
              pagination={{
                current: pagination.page,
                pageSize: pagination.limit,
                total: pagination.total,
                onChange: (p, ps) => fetchData(p, ps),
                showSizeChanger: true,
              }}
              scroll={{ x: true }}
            />
          </Card>
        </div>
      </div>
    </div>
  );
}
