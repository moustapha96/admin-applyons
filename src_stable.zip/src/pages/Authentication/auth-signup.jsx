/* eslint-disable react/no-unescaped-entities */
import { useEffect, useState, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import logoImg from "../../assets/logo.png";
import Switcher from "../../components/switcher";
import BackButton from "../../components/backButton";
import authService from "../../services/authService";
import { toast } from "sonner";
import applyonsAbout1 from "../../assets/logo.png";
import { message } from "antd";
import countries from "@/assets/countries.json";


export default function Signup() {
  const [formData, setFormData] = useState({
    // Données utilisateur
    email: "",
    password: "",
    confirmPassword: "",
    firstName: "",
    lastName: "",
    phone: "",
    adress: "",
    country: "SN",
    gender: "MALE",
    role: "DEMANDEUR",
    birthPlace: "",         // NEW
    birthDate: "",          // NEW (YYYY-MM-DD)

    // Données organisation
    orgName: "",
    orgType: "UNIVERSITE",
    orgEmail: "",
    orgPhone: "",
    orgWebsite: "",
    orgAddress: "",
  });

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const navigate = useNavigate();

  const roleOptions = [
    { value: "DEMANDEUR", label: "Demandeur" },
    { value: "INSTITUT", label: "Institut/École/Entreprise" },
    { value: "TRADUCTEUR", label: "Traducteur/Agence" },
    { value: "BANQUE", label: "Banque/Institution financière" },
  ];

  const orgTypeOptions = {
    INSTITUT: [
      { value: "UNIVERSITE", label: "Université" },
      { value: "COLLEGE", label: "Collège" },
      { value: "LYCEE", label: "Lycée" },
      { value: "ENTREPRISE", label: "Entreprise" },
    ],
    TRADUCTEUR: [{ value: "TRADUCTEUR", label: "Agence de traduction" }],
    BANQUE: [{ value: "BANQUE", label: "Banque" }],
  };

  const genderOptions = [
    { value: "MALE", label: "Homme" },
    { value: "FEMALE", label: "Femme" },
    { value: "OTHER", label: "Autre" },
  ];


  useEffect(() => {
    const htmlTag = document.documentElement;
    htmlTag.setAttribute("dir", "ltr");
    htmlTag.classList.add("light");
    htmlTag.classList.remove("dark");
  }, []);

  const roleNeedsOrganization = (role) => ["INSTITUT", "TRADUCTEUR", "BANQUE"].includes(role);
  const visibleOrgTypes = useMemo(() => orgTypeOptions[formData.role] || [], [formData.role]);

  const isValidBirthDate = (yyyyMmDd) => {
    if (!yyyyMmDd) return false;
    const d = new Date(yyyyMmDd);
    const today = new Date();
    if (Number.isNaN(d.getTime())) return false;
    // entre 1900-01-01 et aujourd’hui
    const min = new Date("1900-01-01");
    return d >= min && d <= today;
  };

  const validateForm = () => {
    const newErrors = {};

    // User
    if (!formData.firstName) newErrors.firstName = "Le prénom est obligatoire.";
    if (!formData.lastName) newErrors.lastName = "Le nom est obligatoire.";
    if (!formData.gender) newErrors.gender = "Le genre est obligatoire.";

    if (!formData.birthPlace) newErrors.birthPlace = "Le lieu de naissance est obligatoire."; // NEW
    if (!formData.birthDate) newErrors.birthDate = "La date de naissance est obligatoire."; // NEW
    else if (!isValidBirthDate(formData.birthDate))
      newErrors.birthDate = "Date de naissance invalide.";

    if (!formData.email) newErrors.email = "L'email est obligatoire.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = "Email invalide.";

    if (!formData.password) newErrors.password = "Le mot de passe est obligatoire.";
    else if (formData.password.length < 6) newErrors.password = "Au moins 6 caractères.";

    if (formData.password !== formData.confirmPassword)
      newErrors.confirmPassword = "Les mots de passe ne correspondent pas.";

    // Organization si nécessaire
    if (roleNeedsOrganization(formData.role)) {
      if (!formData.orgName) newErrors.orgName = "Le nom de l'organisation est obligatoire.";
      if (!formData.orgType) newErrors.orgType = "Le type d'organisation est obligatoire.";
      if (!formData.orgEmail) newErrors.orgEmail = "L'email de l'organisation est obligatoire.";
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.orgEmail))
        newErrors.orgEmail = "Email d'organisation invalide.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    console.log(name, value)
    if (name === "role") {
      const firstType = (orgTypeOptions[value] && orgTypeOptions[value][0]?.value) || "";
      setFormData((prev) => ({
        ...prev,
        role: value,
        orgType: firstType,
      }));
      return;
    }

    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const generateSlug = (name) =>
    name
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, "")
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .trim();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsLoading(true);
    const username =
      formData.username ||
      `${(formData.firstName || "").toLowerCase()}_${(formData.lastName || "").toLowerCase()}`.replace(
        /[^a-z0-9_]/g,
        ""
      );

    try {
      if (formData.role === "DEMANDEUR") {
        // ➜ User seul
        const userPayload = {
          email: formData.email,
          password: formData.password,
          role: "DEMANDEUR",
          firstName: formData.firstName,
          lastName: formData.lastName,
          phone: formData.phone,
          country: formData.country,
          adress: formData.adress,
          gender: formData.gender,
          username,
          birthPlace: formData.birthPlace,                // NEW
          birthDate: formData.birthDate,                  // NEW (YYYY-MM-DD)
        };

        await authService.register(userPayload);
        message.success("Inscription réussie ! Vérifiez votre email pour activer le compte.");
        navigate("/auth/login");
      } else {
        // ➜ User + Organization
        const payload = {
          user: {
            email: formData.email,
            password: formData.password,
            role: formData.role,
            firstName: formData.firstName,
            lastName: formData.lastName,
            phone: formData.phone,
            country: formData.country,
            adress: formData.adress,
            gender: formData.gender,
            username,
            birthPlace: formData.birthPlace,              // NEW
            birthDate: formData.birthDate,                // NEW
          },
          organization: {
            name: formData.orgName,
            slug: generateSlug(formData.orgName),
            type: formData.orgType,
            email: formData.orgEmail,
            phone: formData.orgPhone,
            address: formData.orgAddress,
            website: formData.orgWebsite,
            country: formData.country,
          },
        };

        await authService.createWithOrganization(payload);
        toast.success("Inscription réussie ! Vérifiez votre email pour activer le compte.");
        navigate("/auth/login");
      }
    } catch (err) {
      console.error(err);
      const errorMessage =
        err?.response?.data?.message || err?.message || "Une erreur est survenue lors de l'inscription.";
      toast.error(errorMessage);
      if (err?.response?.data?.errors) {
        setErrors(
          err.response.data.errors.reduce((acc, error) => {
            acc[error.path] = error.msg;
            return acc;
          }, {})
        );
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <section
        className="min-h-screen py-12 md:py-20 flex items-center relative bg-no-repeat bg-center bg-cover"
        style={{ backgroundImage: `url(${applyonsAbout1})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/70" />
        <div className="container relative px-4">
          <div className="flex justify-center">
            <div className="w-full max-w-4xl mx-auto p-6 bg-white dark:bg-slate-900 shadow-md dark:shadow-gray-800 rounded-md">
              <div className="text-center mb-6">
                <Link to="/">
                  <img src={logoImg} className="mx-auto h-16" alt="applyons" />
                </Link>
              </div>

              <h5 className="mb-6 text-xl font-semibold text-slate-800 dark:text-white text-center">
                Créer un compte
              </h5>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Bloc Infos personnelles + rôle */}
                <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg">
                  <h6 className="mb-4 text-lg font-medium text-slate-700 dark:text-slate-200">
                    Informations personnelles
                  </h6>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Prénom *</label>
                      <input
                        id="firstName"
                        name="firstName"
                        type="text"
                        className={`w-full px-3 py-2 border ${errors.firstName ? "border-red-500" : "border-gray-300"
                          } rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]`}
                        placeholder="Jean"
                        value={formData.firstName}
                        onChange={handleChange}
                      />
                      {errors.firstName && <p className="mt-1 text-xs text-red-600">{errors.firstName}</p>}
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-1">Nom *</label>
                      <input
                        id="lastName"
                        name="lastName"
                        type="text"
                        className={`w-full px-3 py-2 border ${errors.lastName ? "border-red-500" : "border-gray-300"
                          } rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]`}
                        placeholder="Dupont"
                        value={formData.lastName}
                        onChange={handleChange}
                      />
                      {errors.lastName && <p className="mt-1 text-xs text-red-600">{errors.lastName}</p>}
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-1">Genre *</label>
                      <select
                        id="gender"
                        name="gender"
                        className={`w-full px-3 py-2 border ${errors.gender ? "border-red-500" : "border-gray-300"
                          } rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]`}
                        value={formData.gender}
                        onChange={handleChange}
                      >
                        {genderOptions.map((opt) => (
                          <option key={opt.value} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                      {errors.gender && <p className="mt-1 text-xs text-red-600">{errors.gender}</p>}
                    </div>

                    {/* NEW: Lieu de naissance */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Pays de naissance *</label>
                      <select
                        id="birthPlace"
                        name="birthPlace"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]"
                        value={formData.birthPlace}
                        onChange={handleChange}
                      >
                        {countries.map((opt) => (
                          <option key={opt.name} value={opt.name}>
                            {opt.name}
                          </option>
                        ))}
                      </select>
                      {errors.birthPlace && <p className="mt-1 text-xs text-red-600">{errors.birthPlace}</p>}
                    </div>

                    {/* NEW: Date de naissance */}
                    <div>
                      <label className="block text-sm font-medium mb-1">Date de naissance *</label>
                      <input
                        id="birthDate"
                        name="birthDate"
                        type="date"
                        max={new Date().toISOString().split("T")[0]}
                        className={`w-full px-3 py-2 border ${errors.birthDate ? "border-red-500" : "border-gray-300"
                          } rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]`}
                        value={formData.birthDate}
                        onChange={handleChange}
                      />
                      {errors.birthDate && <p className="mt-1 text-xs text-red-600">{errors.birthDate}</p>}
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium mb-1">Adresse email *</label>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        className={`w-full px-3 py-2 border ${errors.email ? "border-red-500" : "border-gray-300"
                          } rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]`}
                        placeholder="jeandupont@example.com"
                        value={formData.email}
                        onChange={handleChange}
                      />
                      {errors.email && <p className="mt-1 text-xs text-red-600">{errors.email}</p>}
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-1">Téléphone</label>
                      <input
                        id="phone"
                        name="phone"
                        type="tel"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]"
                        placeholder="+221 77 000 00 00"
                        value={formData.phone}
                        onChange={handleChange}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-1">Pays *</label>
                      <select
                        id="country"
                        name="country"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]"
                        value={formData.country}
                        onChange={handleChange}
                      >
                        {countries.map((opt) => (
                          <option key={opt.name} value={opt.name}>
                            {opt.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium mb-1">Adresse</label>
                      <input
                        id="adress"
                        name="adress"
                        type="text"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]"
                        placeholder="123 rue de la paix, Dakar"
                        value={formData.adress}
                        onChange={handleChange}
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium mb-1">Type de compte *</label>
                      <select
                        id="role"
                        name="role"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]"
                        value={formData.role}
                        onChange={handleChange}
                      >
                        {roleOptions.map((opt) => (
                          <option key={opt.value} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-1">Mot de passe *</label>
                      <div className="relative">
                        <input
                          id="password"
                          name="password"
                          type={showPassword ? "text" : "password"}
                          className={`w-full px-3 py-2 border ${errors.password ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)] pr-10`}
                          placeholder="••••••••"
                          value={formData.password}
                          onChange={handleChange}
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute inset-y-0 right-0 flex items-center pr-3"
                          aria-label={showPassword ? "Masquer" : "Afficher"}
                        >
                          {showPassword ? (
                            <i className="mdi mdi-eye-off-outline text-xl text-gray-500" />
                          ) : (
                            <i className="mdi mdi-eye-outline text-xl text-gray-500" />
                          )}
                        </button>
                      </div>
                      {errors.password && <p className="mt-1 text-xs text-red-600">{errors.password}</p>}
                      <p className="mt-1 text-xs text-gray-500">Minimum 6 caractères</p>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-1">Confirmer le mot de passe *</label>
                      <div className="relative">
                        <input
                          id="confirmPassword"
                          name="confirmPassword"
                          type={showConfirmPassword ? "text" : "password"}
                          className={`w-full px-3 py-2 border ${errors.confirmPassword ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)] pr-10`}
                          placeholder="••••••••"
                          value={formData.confirmPassword}
                          onChange={handleChange}
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute inset-y-0 right-0 flex items-center pr-3"
                          aria-label={showConfirmPassword ? "Masquer" : "Afficher"}
                        >
                          {showConfirmPassword ? (
                            <i className="mdi mdi-eye-off-outline text-xl text-gray-500" />
                          ) : (
                            <i className="mdi mdi-eye-outline text-xl text-gray-500" />
                          )}
                        </button>
                      </div>
                      {errors.confirmPassword && (
                        <p className="mt-1 text-xs text-red-600">{errors.confirmPassword}</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Bloc Organisation (affiché uniquement si le rôle le requiert) */}
                {roleNeedsOrganization(formData.role) && (
                  <div className="bg-gray-50 dark:bg-slate-800 p-4 rounded-lg">
                    <h6 className="mb-4 text-lg font-medium text-slate-700 dark:text-slate-200">
                      {formData.role === "INSTITUT"
                        ? "Informations de l'institution"
                        : formData.role === "TRADUCTEUR"
                          ? "Informations de l'agence"
                          : "Informations de la banque"}
                    </h6>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Nom de l'organisation *</label>
                        <input
                          id="orgName"
                          name="orgName"
                          type="text"
                          className={`w-full px-3 py-2 border ${errors.orgName ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]`}
                          placeholder={
                            formData.role === "INSTITUT"
                              ? "Nom de votre institution"
                              : formData.role === "TRADUCTEUR"
                                ? "Nom de votre agence"
                                : "Nom de votre banque"
                          }
                          value={formData.orgName}
                          onChange={handleChange}
                        />
                        {errors.orgName && <p className="mt-1 text-xs text-red-600">{errors.orgName}</p>}
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-1">Type d'organisation *</label>
                        <select
                          id="orgType"
                          name="orgType"
                          className={`w-full px-3 py-2 border ${errors.orgType ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]`}
                          value={formData.orgType}
                          onChange={handleChange}
                        >
                          <option value="">Sélectionnez un type</option>
                          {visibleOrgTypes.map((opt) => (
                            <option key={opt.value} value={opt.value}>
                              {opt.label}
                            </option>
                          ))}
                        </select>
                        {errors.orgType && <p className="mt-1 text-xs text-red-600">{errors.orgType}</p>}
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-1">Email de l'organisation *</label>
                        <input
                          id="orgEmail"
                          name="orgEmail"
                          type="email"
                          className={`w-full px-3 py-2 border ${errors.orgEmail ? "border-red-500" : "border-gray-300"
                            } rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]`}
                          placeholder="contact@organisation.com"
                          value={formData.orgEmail}
                          onChange={handleChange}
                        />
                        {errors.orgEmail && <p className="mt-1 text-xs text-red-600">{errors.orgEmail}</p>}
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-1">Téléphone de l'organisation</label>
                        <input
                          id="orgPhone"
                          name="orgPhone"
                          type="tel"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]"
                          placeholder="+221 77 000 00 00"
                          value={formData.orgPhone}
                          onChange={handleChange}
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-1">Site web (optionnel)</label>
                        <input
                          id="orgWebsite"
                          name="orgWebsite"
                          type="url"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]"
                          placeholder="https://organisation.com"
                          value={formData.orgWebsite}
                          onChange={handleChange}
                        />
                      </div>

                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium mb-1">Adresse de l'organisation</label>
                        <input
                          id="orgAddress"
                          name="orgAddress"
                          type="text"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-[var(--applyons-blue)] focus:border-[var(--applyons-blue)]"
                          placeholder="Adresse complète de l'organisation"
                          value={formData.orgAddress}
                          onChange={handleChange}
                        />
                      </div>
                    </div>

                    <div className="mt-4 p-3 bg-blue-50 rounded-md">
                      <p className="text-sm text-blue-800">
                        <strong>Note :</strong> Vous serez automatiquement <strong>administrateur</strong> de cette
                        organisation.
                      </p>
                    </div>
                  </div>
                )}

                <div className="flex justify-between ">
                  
                  <div  className="flex justify-between" >
                    <button
                      type="button"
                      className="py-2 px-4 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
                      onClick={() => navigate("/auth/login")}
                    >
                      Annuler
                    </button>

                    <button
                      type="button"
                      className="py-2 px-4 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
                      onClick={() => navigate("/auth/login")}
                    >
                      Se connecter
                    </button>
                  </div>


                  <button
                    type="submit"
                    disabled={isLoading}
                    className={`py-2 px-4 bg-[var(--applyons-blue)] text-white rounded-md hover:bg-[var(--applyons-blue-dark)] ${isLoading ? "opacity-70 cursor-not-allowed" : ""
                      }`}
                  >
                    {isLoading ? (
                      <>
                        <span className="inline-block animate-spin mr-2">↻</span>
                        Inscription en cours...
                      </>
                    ) : formData.role === "DEMANDEUR" ? "Créer mon compte" : "Créer le compte et l'organisation"}
                  </button>
                </div>
              </form>

              <div className="text-center mt-6 pt-4 border-t border-gray-200 dark:border-gray-800">
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  © {new Date().getFullYear()} applyons. Réalisé par{" "}
                  <Link
                    to="https://alhussein-khouma.vercel.app/"
                    target="_blank"
                    className="text-[var(--applyons-blue)] hover:underline"
                  >
                    AuthenticPage
                  </Link>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Switcher />
      <BackButton />
    </>
  );
}

