// src/context/AppContext.ts
import { createContext } from 'react';

export const AppContext = createContext(undefined);
